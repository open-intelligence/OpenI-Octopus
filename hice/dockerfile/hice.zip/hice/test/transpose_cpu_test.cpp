#include <iostream>
#include "hice.h"

using namespace std;

#define GENERATOR -1

template<typename T>
void initTensor(Tensor<T, 1> &tensor, int init_value){
  for (int i = 0; i < tensor.dim(0); ++i)
      tensor(i) = init_value;
}

template<typename T>
void initTensor(Tensor<T, 2> &tensor, int init_value){
  for (int row = 0; row < tensor.dim(0); ++row)
    for (int col = 0; col < tensor.dim(1); ++col)
      tensor(row, col) = row-col;
}

int main(){
  
  std::cout << "================================" << std::endl;
  std::cout << "       transpose_cpu test       " << std::endl;
  std::cout << "================================" << std::endl;
    
  Tensor<double, 2> mat1(8, 8);
  Tensor<double, 2> mat2(8, 8);
  Tensor<double, 1> vec1(8);
  Tensor<double, 1> vec2(8);
  Tensor<double, 0> result_0d;
  Tensor<double, 1> result_1d(8);
  Tensor<double, 2> result_2d(8, 8);

  initTensor(mat1, GENERATOR);
  initTensor(mat2, GENERATOR);
  initTensor(vec1, GENERATOR);
  initTensor(vec2, GENERATOR);
  
  std::cout << "mat1: " << std::endl;
  std::cout << mat1 << std::endl;
  std::cout << "mat2: " << std::endl;
  std::cout << mat2 << std::endl;
  std::cout << "vec1: " << std::endl;
  std::cout << vec1 << std::endl;
  std::cout << "vec2: " << std::endl;
  std::cout << vec2 << std::endl;
  
  int case_count = 1;

  std::cout << "Test case "<<case_count++<<": transpose(mat1)" << std::endl;
  result_2d = transpose(mat1);
  std::cout << result_2d << std::endl;

  std::cout << "====================================" << std::endl;
  std::cout << "All transpose_cpu test cases passed!" << std::endl;
  std::cout << "====================================" << std::endl;
  std::cout << std::endl<< std::endl<< std::endl;
}