#include <iostream>
#include "hice.h"

using namespace std;

template<typename T>
void initTensor(Tensor<T, 1> &tensor, int init_value){
  for (int i = 0; i < tensor.dim(0); ++i)
      tensor(i) = init_value;
}

template<typename T>
void initTensor(Tensor<T, 2> &tensor, int init_value){
  for (int row = 0; row < tensor.dim(0); ++row)
    for (int col = 0; col < tensor.dim(1); ++col)
      tensor(row, col) = init_value;
}

int main() {
  
  std::cout << "================================" << std::endl;
  std::cout << "          dot_cpu test          " << std::endl;
  std::cout << "================================" << std::endl;

  Tensor<double, 2> mat1(8, 8);
  Tensor<double, 2> mat2(8, 8);
  Tensor<double, 1> vec1(8);
  Tensor<double, 1> vec2(8);
  Tensor<double, 0> result_0d;
  Tensor<double, 1> result_1d(8);
  Tensor<double, 2> result_2d(8, 8);

  initTensor(mat1,1);
  initTensor(mat2,1);
  initTensor(vec1,1);
  initTensor(vec2,1);
  
  std::cout << "mat1: " << std::endl;
  std::cout << mat1 << std::endl;
  std::cout << "mat2: " << std::endl;
  std::cout << mat2 << std::endl;
  std::cout << "vec1: " << std::endl;
  std::cout << vec1 << std::endl;
  std::cout << "vec2: " << std::endl;
  std::cout << vec2 << std::endl;

  int case_count = 1;

  std::cout << "Test case "<<case_count++<<": result_1d = vec1" << std::endl;
  result_1d = vec1;
  std::cout << result_1d << std::endl;
  
  std::cout << "Test case "<<case_count++<<": dot(mat1, vec1)" << std::endl;
  result_1d = dot(mat1, vec1);
  std::cout << result_1d << std::endl;

  std::cout << "Test case "<<case_count++<<": dot(mat1, vec1).to(CPU)" << std::endl;
  result_1d = dot(mat1, vec1).to(CPU);
  std::cout << result_1d << std::endl;
  
  std::cout << "Test case "<<case_count++<<": dot(mat1, mat2)" << std::endl;
  result_2d = dot(mat1, mat2).to(CUDA);
  std::cout << result_2d << std::endl;

  std::cout << "Test case "<<case_count++<<": dot(mat1, vec1)" << std::endl;
  result_1d = dot(mat1, vec1).to(CPU);
  std::cout << result_1d << std::endl;

  // std::cout << "Test case "<<case_count++<<": auto tmp = mat * vec1" << std::endl;
  // auto tmp = mat * vec1;  /* undefined operator */
  // result = tmp;
  // std::cout << result << std::endl;

  std::cout << "Test case "<<case_count++<<": dot(vec1, vec2)" << std::endl;
  result_0d = dot(vec1, vec2).to(CPU);
  std::cout << result_0d << std::endl;

  std::cout << "Test case "<<case_count++<<": dot(mat1,vec1) + vec2" << std::endl;
  result_1d = (dot(mat1,vec1) + vec2).to(CPU);
  std::cout << result_1d << std::endl;

  std::cout << "Test case "<<case_count++<<": dot(mat1, vec1).eval() + vec2" << std::endl;
  result_1d = (dot(mat1, vec1).eval() + vec2).to(CPU);
  std::cout << result_1d << std::endl;

  std::cout << "Test case "<<case_count++<<": mat1 + (mat2 * 3).eval()" << std::endl;
  result_2d = (mat1 + (mat2 * 3).eval()).to(CPU);
  std::cout << result_2d << std::endl;

  std::cout << "==============================" << std::endl;
  std::cout << "All dot_cpu test cases passed!" << std::endl;
  std::cout << "==============================" << std::endl;
  std::cout << std::endl<< std::endl<< std::endl;

  return 0;
}
