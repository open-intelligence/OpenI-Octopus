#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include "hice.h"

int main() {

    int ref_num = 10;
    int query_num = 10;
    int dim = 3;
    int k = 2;

    Tensor<float, 2> ref(ref_num, dim);
    Tensor<float, 2> query(query_num, dim);
    Tensor<float, 2> label(ref_num, 1);
    Tensor<int, 1> result1(query_num);
    Tensor<int, 1> result2(query_num);

    srand(time(NULL));
    for (int row = 0; row < ref.dim(0); ++row){
        for (int col = 0; col < ref.dim(1); ++col){
            ref(row, col) = rand() % 10;
        }
        label(row) = row % 5;
    }

    for (int row = 0; row < query.dim(0); ++row){
        for (int col = 0; col < query.dim(1); ++col){
            query(row, col) = rand() % 10;
        }
    }

    // std::cout<<ref<<std::endl;
    // std::cout<<query<<std::endl;

    // Tensor<float, 2> ref(4, 4);
    // Tensor<float, 2> query(1, 4);
    // Tensor<float, 2> label(1, 1);
    // Tensor<int, 1> result1(1);
    // Tensor<int, 1> result2(1);
  
    // ref(0,0) = 1;
    // ref(0,1) = 1;
    // ref(0,2) = 1;
    // ref(0,3) = 1;
    // ref(1,0) = 2;
    // ref(1,1) = 2;
    // ref(1,2) = 2;
    // ref(1,3) = 2;
    // ref(2,0) = 3;
    // ref(2,1) = 3;
    // ref(2,2) = 3;
    // ref(2,3) = 3;
    // ref(3,0) = 4;
    // ref(3,1) = 4;
    // ref(3,2) = 4;
    // ref(3,3) = 4;
    // query(0,0) = 1;
    // query(0,1) = 1;
    // query(0,2) = 1;
    // query(0,3) = 1;
    // label(0,0) = 1;
    // label(0,1) = 1;
    // label(0,2) = 0;
    // label(0,3) = 2;
    struct timeval start;
    struct timeval end;
    unsigned long dur;

    // gettimeofday(&start,NULL);
    result1 = knn(ref, label, query, k);
    // gettimeofday(&end,NULL);
    // dur = 1000000*(end.tv_sec-start.tv_sec)+ end.tv_usec-start.tv_usec;
    // std::cout<<"Serial Knn "<<(double)dur/1000000<<"s."<<std::endl;
    std::cout << result1 << std::endl;

    // gettimeofday(&start,NULL);
    result2 = knn(ref, label, query, k).to(CUDA);
    // gettimeofday(&end,NULL);
    // dur = 1000000*(end.tv_sec-start.tv_sec)+ end.tv_usec-start.tv_usec;
    // std::cout<<"Parallel Knn "<<(double)dur/1000000<<"s."<<std::endl;
    std::cout << result2 << std::endl;

}
