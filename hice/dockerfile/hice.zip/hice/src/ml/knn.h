#ifndef HICE_KNN_H
#define HICE_KNN_H

#include "../core/tensor.h"
#include <sys/time.h>
#include <math.h>
#include <unordered_map>
#include "knn_helper.cuh"


// Step 1: Write the knn engine with the underlying kernels
namespace engine{

    // CPU kernel
    template< DeviceType Td, typename TMat, typename TVec>
    typename std::enable_if<is_same_device<Td, DeviceType::kCPU>::value, void>::type
    knn(const TMat &ref, const TMat &label, const TMat &query, const int k, TVec &result){
        const int ref_num = ref.dim(0);
        const int query_num = query.dim(0);
        const int dim = query.dim(1);

        typedef float T;
        // const T *x = (const T*)ref.data();
        // const T *y = (const T*)query.data();
        // int *res = result.data();
        T* dist = new T[query_num*ref_num];
        int* indices = new int[query_num*k];

        // EulerDistance
        for(int i = 0;i<query_num;i++){
            for(int j = 0;j<ref_num;j++){
                T d = 0.0;
                for(int k = 0;k<dim;k++){
                    T diff = query(i,k) - ref(j,k);
                    d += diff * diff;
                }
                dist[i * ref_num + j] = sqrtf(d);
            }
        }

        // for(int i = 0;i<query_num;i++){
        //     for(int j = 0;j<ref_num;j++){
        //         std::cout<<dist[i * ref_num + j]<<" ";
        //     }
        //     std::cout<<std::endl;
        // }
        
        // gettimeofday(&start,NULL);
        // Top K
        for(int i = 0;i<query_num;i++){
            indices[i*k] = 0;
            for(int j = 1;j<ref_num;j++){
                if(j >= k && dist[i*ref_num + j] >= dist[i * ref_num + k - 1] ){
                    continue;
                }
                
                int index = std::min(j, k-1);
                while(index > 0 && dist[i * ref_num + index-1] > dist[i * ref_num + j]){
                    dist[i * ref_num + index] = dist[i * ref_num + index-1];
                    indices[i * k + index] = indices[i * k + index-1];
                    index--;
                }
                
                dist[i * ref_num + index] = dist[i * ref_num + j];
                indices[i * k + index] = j;
            }
        }
        // gettimeofday(&end,NULL);
        // dur = 1000000*(end.tv_sec-start.tv_sec)+ end.tv_usec-start.tv_usec;
        // std::cout<<"Serial Top K "<<(double)dur/1000000<<"s."<<std::endl;

        // for(int i = 0;i<query_num;i++){
        //     for(int j = 0;j<k;j++){
        //         std::cout<<indices[i * k + j]<<" ";
        //     }
        //     std::cout<<std::endl;
        // }

        // Choose the most frequent one
        for(int i = 0;i<query_num;i++){
            std::unordered_map<int,int> count;
            int label_ = -1;
            for(int j = 0;j<k;j++){
                int index = label(indices[i * k + j],0);
                int maxCount = 0;
                std::unordered_map<int,int>::iterator it = count.find(index);
                if(it != count.end()){
                    it->second++;
                }
                else{
                    count.insert(std::make_pair(index, 1));
                }
                if(count[index] > maxCount){
                    maxCount = count[index];
                    label_ = index;
                }
            }
            result(i) = label_;
        }
        delete dist;
        delete indices;
    }

    // GPU kernel
    template< DeviceType Td, typename TMat, typename TVec>
    typename std::enable_if<is_same_device<Td, DeviceType::kCUDA>::value, void>::type
    knn(const TMat &ref, const TMat &label, const TMat &query, const int k, TVec &result){
        std::cout<<"*****USE CUDA FOR KNN*****"<<std::endl;

        const int ref_num = ref.dim(0);
        const int query_num = query.dim(0);
        const int dim = query.dim(1);

        // struct timeval start;
        // struct timeval end;
        // unsigned long dur;

        // gettimeofday(&start,NULL);

        typedef float T;
        const T *d_ref = (const T*)ref.device_data();
        const T *d_query = (const T*)query.device_data();

        Tensor<T,2> dist(query_num, ref_num);

        (dist).to_device(ref.device());

        T* d_dist = (T*)dist.device_data();

        CUDAContext *cuda_ctx = cuda_context(ref.device());
        cublasHandle_t handle = cuda_ctx->cublas_handle();

        // gettimeofday(&end,NULL);
        // dur = 1000000*(end.tv_sec-start.tv_sec)+ end.tv_usec-start.tv_usec;
        // std::cout<<"Get Ready for Parallel "<<(double)dur/1000000<<"s."<<std::endl;

        // gettimeofday(&start,NULL);

        // ref(ref_num,dim), query(query_num,dim), dist(query_num, ref_num)
        float alpha = -2.0;
        float beta = 0.0;
        
        cublasSgemm(handle, CUBLAS_OP_T, CUBLAS_OP_N, 
        ref_num, query_num, dim, &alpha, d_ref, dim, d_query, dim, &beta, d_dist, ref_num);

        EulerHelper(d_ref, d_query, ref_num, query_num, dim, d_dist);

        // gettimeofday(&end,NULL);
        // dur = 1000000*(end.tv_sec-start.tv_sec)+ end.tv_usec-start.tv_usec;
        // std::cout<<"Parallel EulerDistance "<<(double)dur/1000000<<"s."<<std::endl;

        // dist.to_host();
        // std::cout<<dist<<std::endl;

        int* indices = new int[k*query_num];

        // gettimeofday(&start,NULL);
        TopK(d_dist, ref_num, query_num, k, indices);
        // gettimeofday(&end,NULL);
        // dur = 1000000*(end.tv_sec-start.tv_sec)+ end.tv_usec-start.tv_usec;
        // std::cout<<"Parallel Top K "<<(double)dur/1000000<<"s."<<std::endl;
   

        // for(int i = 0;i<query_num;i++){
        //     for(int j = 0;j<k;j++){
        //         std::cout<<indices[i * k + j]<<" ";
        //     }
        //     std::cout<<std::endl;
        // }

        // gettimeofday(&start,NULL);
        // Choose the most frequent one
        for(int i = 0;i<query_num;i++){
            std::unordered_map<int,int> count;
            int label_ = -1;
            for(int j = 0;j<k;j++){
                int index = label(indices[i * k + j],0);
                int maxCount = 0;
                std::unordered_map<int,int>::iterator it = count.find(index);
                if(it != count.end()){
                    it->second++;
                }
                else{
                    count.insert(std::make_pair(index, 1));
                }
                if(count[index] > maxCount){
                    maxCount = count[index];
                    label_ = index;
                }
            }
            result(i) = label_;
        }
        // gettimeofday(&end,NULL);
        // dur = 1000000*(end.tv_sec-start.tv_sec)+ end.tv_usec-start.tv_usec;
        // std::cout<<"Finally Select "<<(double)dur/1000000<<"s."<<std::endl;
        delete indices;
    }
};

// Step 2: Write the knn operator
namespace op{
    struct knn{
        template<typename TScalarType, typename TIndexType, StorageType stype>
        inline static void apply(Tensor<TScalarType, 2, TIndexType, stype> &ref,
                    Tensor<TScalarType, 2, TIndexType, stype> &label,
                    Tensor<TScalarType, 2, TIndexType, stype> &query,
                    int k,
                    Tensor<int, 1, TIndexType, stype> &result){
            
            if (ref.device() == query.device()) {
                if (ref.device().is_cpu()) {
                    engine::knn<DeviceType::kCPU>(ref, label, query, k, result);
                }
                else if(ref.device().is_cuda()){
                    engine::knn<DeviceType::kCUDA>(ref, label, query, k, result);
                }
            }
            else{

            }   
        }
    };
};

// Step 3: Define the KnnExpr
template<typename T>
class KnnExpr: public Expr<KnnExpr<T>> {
public:
    explicit KnnExpr(const T &ref, const T &label, const T &query, const int &k)
        : ref_(ref), label_(label), query_(query), k_(k), device_(DeviceType::kCPU) {}
    
    const T& ref() const { return ref_; }

    const T& label() const { return label_; }
 
    const T& query() const { return query_; }

    const int& k() const { return k_; }
 
    const Device& device() const { return device_; } 

    void to_device(Device device) { 
        const_cast<T &>(ref_).to_device(device);
        // const_cast<T &>(label_).to_device(device);
        const_cast<T &>(query_).to_device(device);
        // (k_).to_device(device);
        device_ = device;
    }

    void off_device(Device device) {
        ref_.off_device(device);
        // label_.off_device(label);
        query_.off_device(device);
        // k_.off_device(device);
        device_ = Device(DeviceType::kCPU); 
    }

private:
 	const T &ref_;
 	const T &query_;
    const T &label_;
    const int &k_;
    Device device_;
};

// May need the helper function for KnnExpr
template<typename T>
inline KnnExpr<T>
knn(const Expr<T> &ref, const Expr<T> &label, const Expr<T> &query, const int &k) {
  return KnnExpr<T>(ref.self(), label.self(), query.self(), k);
}

// May need the traits of KnnExpr
template<typename T>
struct Traits<KnnExpr<T>> {
  static const int kDim = 1;
  static const StorageType kSType = Traits<T>::kSType;
  typedef typename Traits<T>::ScalarType ScalarType;
  typedef typename Traits<T>::IndexType IndexType;
  typedef TensorShape<IndexType, kDim> ShapeType;
  typedef Tensor<int, kDim, IndexType, kSType> ResultType;
};

template<typename TScalarType, typename TIndexType, StorageType stype>
struct Traits<KnnExpr<Tensor<TScalarType, 2, TIndexType, stype>>> {
  static const int kDim = 1;
  static const StorageType kSType = stype;
  typedef TScalarType ScalarType;
  typedef TIndexType IndexType;
  typedef TensorShape<IndexType, kDim> ShapeType;
  typedef Tensor<int, kDim, TIndexType, stype> ResultType;
};

// Step 4: Write the evaluator for KnnExpr
template<typename TScalarType, typename TIndexType, StorageType stype>

class Evaluator<KnnExpr<Tensor<TScalarType, 2, TIndexType, stype>>> {
 public:
     typedef Tensor<TScalarType, 2, TIndexType, stype> T;
     typedef KnnExpr<T> ExprType;
     static const int kDim = Traits<ExprType>::kDim;
     typedef typename Traits<ExprType>::IndexType IndexType;
     typedef typename Traits<ExprType>::ShapeType ShapeType;
     typedef typename Traits<ExprType>::ResultType ResultType;
     typedef typename Traits<ExprType>::ScalarType ScalarType;

    explicit Evaluator(const ExprType &expr)
      : ref_eval_(expr.ref()), label_eval_(expr.label()), query_eval_(expr.query()), 
        k_(expr.k()), result_(), shape_(query_eval_.shape().dim(0)),
        device_(expr.device()) {}

    const ShapeType& shape() const {
        return shape_;
    }

    const Device& device() const {
        return device_;
    }

    // this function will be called if there will be element-wise operation in run(). 
    void eval_sub_expr_to_support_element_wise(){
        this->run();
    }

    ResultType& run() {
        result_.resize(shape());
        op::knn::apply(ref_eval_.run(), label_eval_.run(), query_eval_.run(), k_, result_);
        return result_;
    }


    // calculate
    ScalarType calc(IndexType i){
        ScalarType* data = NULL;
        if (device_.is_cpu()) {
        data = result_.data();
        }else if (device_.is_cuda()) {
        data = result_.device_data();
        }else {

        }
        return data[i];
    }

private:
    Evaluator<T> ref_eval_;
    Evaluator<T> query_eval_;
    Evaluator<T> label_eval_;
    int k_;
    ResultType result_;
    ShapeType shape_;
    Device device_;
};


#endif