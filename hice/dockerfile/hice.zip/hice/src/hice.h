#ifndef HICE_H
#define HICE_H

//#include <limits>
//#include <vector>
//#include <array>
//#include <cstddef>
#include <cmath>
#include <stdlib.h>
#include <iostream>
//#include <type_traits>
//#include <complex>


#include "core/tensor_printer.h"
#include "la/dot.h"
#include "la/transpose.h"
#include "ml/knn.h"

#endif
