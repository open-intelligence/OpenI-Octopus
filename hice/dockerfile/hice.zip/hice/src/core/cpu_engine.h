#ifndef HICE_CPU_ENGINE_H
#define HICE_CPU_ENGINE_H

#include <iostream>
#include <type_traits>
#include "cblas.h"
#include "device.h"

namespace engine {

template<DeviceType Td, typename TScalarType, typename TVec>
typename std::enable_if<is_same_device<Td, DeviceType::kCPU>::value, void>::type
copy(const TVec &lhs, const TVec &rhs) { 
  const int n = lhs.dim(0);
  const int incx = 1;
  const int incy = 1;
  if (std::is_same<TScalarType, float>::value) {
    typedef float T;
    const T *x = (const T*)lhs.data();
    T *y = (T*)rhs.data();
    cblas_scopy(n, x, incx, y, incy);
  } else if (std::is_same<TScalarType, double>::value) {
    typedef double T;
    const T *x = (const T*)lhs.data();
    T *y = (T*)rhs.data();
    cblas_dcopy(n, x, incx, y, incy);
  } else if (std::is_same<TScalarType, std::complex<float>>::value) {
    typedef std::complex<float> T;
    const T *x = (const T*)lhs.data();
    T *y = (T*)rhs.data();
    cblas_ccopy(n, x, incx, y, incy);
  } else if (std::is_same<TScalarType, std::complex<double>>::value) {
    typedef std::complex<double> T;
    const T *x = (const T*)lhs.data();
    T *y = (T*)rhs.data();
    cblas_zcopy(n, x, incx, y, incy);
  }
}

template<DeviceType Td, typename TScalarType, typename TVec>
typename std::enable_if<is_same_device<Td, DeviceType::kCPU>::value, void>::type
axpy(const TVec &lhs, const TVec &rhs,
    const TScalarType alpha = TScalarType(1)) { 
  const int n = lhs.dim(0);
  const int incx = 1;
  const int incy = 1;
  if (std::is_same<TScalarType, float>::value) {
    typedef float T;
    const T *x = (const T*)lhs.data();
    T *y = (T*)rhs.data();
    cblas_saxpy(n, alpha, x, incx, y, incy);
  } else if (std::is_same<TScalarType, double>::value) {
    typedef double T;
    const T *x = (const T*)lhs.data();
    T *y = (T*)rhs.data();
    cblas_daxpy(n, alpha, x, incx, y, incy);
  } else if (std::is_same<TScalarType, std::complex<float>>::value) {
    typedef std::complex<float> T;
    const T *x = (const T*)lhs.data();
    T *y = (T*)rhs.data();
    cblas_caxpy(n, (const T*)&alpha, x, incx, y, incy);
  } else if (std::is_same<TScalarType, std::complex<double>>::value) {
    typedef std::complex<double> T;
    const T *x = (const T*)lhs.data();
    T *y = (T*)rhs.data();
    cblas_zaxpy(n, (const T*)&alpha, x, incx, y, incy);
  }
}

};


#endif
