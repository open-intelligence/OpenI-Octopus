#ifndef HICE_EXPRESSION_TRAITS_H
#define HICE_EXPRESSION_TRAITS_H

#include "expression.h"

// Forward declarations
enum class StorageType;
template <typename TIndexType, int ndim> struct TensorShape;
template<typename TScalarType, int ndim,
         typename TIndexType, StorageType stype> class Tensor;

/// Traits of expressions
template<typename TExpr> struct Traits {};

// UnaryExpr
template<typename TExpr, typename TUnaryOp>
struct Traits<UnaryExpr<TExpr, TUnaryOp>> {
  static const int kDim = Traits<TExpr>::kDim;
  static const StorageType kSType = Traits<TExpr>::kSType;
  typedef typename Traits<TExpr>::ScalarType ScalarType;
  typedef typename Traits<TExpr>::IndexType IndexType;
  typedef typename Traits<TExpr>::ShapeType ShapeType;
  typedef typename Traits<TExpr>::ResultType ResultType;
};

template<typename TScalarType, int ndim, typename TIndexType, 
         StorageType stype>
struct Traits<Tensor<TScalarType, ndim, TIndexType, stype>> {
  static const int kDim = ndim;
  static const StorageType kSType = stype;
  typedef TIndexType IndexType;
  typedef TScalarType ScalarType;
  typedef TensorShape<IndexType, kDim> ShapeType;
  typedef Tensor<ScalarType, kDim, IndexType, stype> ResultType;
};

// ReductionExpr
template<typename TExpr, typename TNullaryOp>
struct Traits<NullaryExpr<TExpr, TNullaryOp>> {
  static const int kDim = Traits<TExpr>::kDim;
  static const StorageType kSType = Traits<TExpr>::kSType;
  typedef typename Traits<TExpr>::ScalarType ScalarType;
  typedef typename Traits<TExpr>::IndexType IndexType;
  typedef typename Traits<TExpr>::ShapeType ShapeType;
  typedef typename Traits<TExpr>::ResultType ResultType; 
};

// BinaryExpr
template<typename TLhs, typename TRhs, typename TBinaryOp>
struct Traits<BinaryExpr<TLhs, TRhs, TBinaryOp>> {
  static const int kLhsDim = Traits<TLhs>::kDim;
  static const int kRhsDim = Traits<TRhs>::kDim;
  static const bool InvalidDim = kLhsDim < 0 && kRhsDim < 0;
  static const bool Matrix_Vector = (kLhsDim == 2 && kRhsDim == 1) || (kLhsDim == 1 && kRhsDim == 2);
  static const int kDim = InvalidDim ? -1 : (
                              kLhsDim == 0 ? kRhsDim : ( 
                                kRhsDim == 0 ? kLhsDim : (
                                  Matrix_Vector ? 1 : (
                                    kLhsDim == kRhsDim ? kLhsDim : -1
                                  )
                                )
                              )
                          );
  static const StorageType kSType = Traits<TLhs>::kSType;
  typedef typename Traits<TLhs>::ScalarType ScalarType;
  typedef typename Traits<TLhs>::IndexType IndexType;
  typedef TensorShape<IndexType, kDim> ShapeType;
  typedef Tensor<ScalarType, kDim, IndexType, kSType> ResultType;
};

template<typename TScalarType1, int ndim, typename TIndexType1, 
         typename TScalarType2, typename TIndexType2,
         StorageType stype>
struct Traits<BinaryExpr<Tensor<TScalarType1, ndim, TIndexType1, stype>, 
                         Tensor<TScalarType2, ndim, TIndexType2, stype>,
                         op::assign>> {
  static const int kDim = ndim;
  static const StorageType kSType = stype;
  typedef TScalarType2 ScalarType;
  typedef TIndexType2 IndexType;
  typedef TensorShape<IndexType, kDim> ShapeType;
  typedef Tensor<ScalarType, kDim, IndexType, kSType> ResultType;
};

#if 0
// DotExpr
template<typename TLhs, typename TRhs>
struct Traits<DotExpr<TLhs, TRhs>> {
  static const int kLhsDim = Traits<TLhs>::kDim;
  static const int kRhsDim = Traits<TRhs>::kDim;
  static const bool InvalidDim = kLhsDim >= 0 && kRhsDim >= 0;
  static const bool Vector_Vector = kLhsDim == 1 && kRhsDim == 1;
  static const bool Matrix_Vector = kLhsDim == 2 && kRhsDim == 1;
  static const bool Matrix_Matrix = kLhsDim == 2 && kRhsDim == 2;
  static const int kDim = InvalidDim ? -1: (
                            Vector_Vector ? 0 : ( 
                              Matrix_Vector ? 1 : (
                                Matrix_Matrix ? 2 : (
                                  kLhsDim == kRhsDim ? kLhsDim : -1
                                )
                              )
                            )
                          );
  static const StorageType kSType = Traits<TLhs>::kSType;
  typedef typename Traits<TLhs>::ScalarType ScalarType;
  typedef typename Traits<TLhs>::IndexType IndexType;
  typedef TensorShape<IndexType, kDim> ShapeType;
  typedef Tensor<ScalarType, kDim, IndexType, kSType> ResultType;
};
#endif

// ReductionExpr
template<typename TExpr, typename TReductionOp, int dim>
struct Traits<ReductionExpr<TExpr, TReductionOp, dim>> {
  static const int kDim = (dim == -1 ? 0 : 1);
  static const StorageType kSType = Traits<TExpr>::kSType;
  typedef typename Traits<TExpr>::ScalarType ScalarType;
  typedef typename Traits<TExpr>::IndexType IndexType;
  typedef typename Traits<TExpr>::ShapeType ShapeType;
  typedef Tensor<ScalarType, kDim, IndexType, kSType> ResultType;
};

#endif
