#ifndef MACRO_H
#define MACRO_H

#ifdef __NVCC__
#define HICE_DEVICE_FUNC __device__ __host__
#else
#define HICE_DEVICE_FUNC 
#endif

#endif