#include  "cpu_allocator.h"

CPUAllocator::~CPUAllocator() {}

void* CPUAllocator::allocate_bytes(size_t num_bytes, size_t alignment) {
  void* p = aligned_malloc(num_bytes, alignment);
  return p;
}

void CPUAllocator::deallocate_bytes(void* ptr) {
  aligned_free(ptr);
}


namespace {

static CPUAllocator cpu_allocator;
REGISTER_ALLOCATOR(DeviceType::kCPU, &cpu_allocator);

} // namespace

CPUAllocator* cpu_allocator() {
  static Allocator* allocator = 
      AllocatorRegister::singleton().get_allocator(DeviceType::kCPU);
  return static_cast<CPUAllocator *>(allocator);
}
