#include "context.h"

DeviceContext* get_context(Device dev) {
  if (dev.is_cpu()) {
    return cpu_context();
  } else if (dev.is_cuda()) {
    return cuda_context(dev);
  } else {
  }
}

DeviceContext* create_context(const Device &dev) {
  DeviceContext *dev_ctx = nullptr;
  if (dev.is_cpu()) {
    dev_ctx = new CPUContext();  
  } else if (dev.is_cuda()) {
    dev_ctx = new CUDAContext(dev.index());  
  } else {

  }
  return dev_ctx;
}

void destory_context(const Device &dev, DeviceContext *dev_ctx) {
  if (dev_ctx)
    delete dev_ctx;
}
