#ifndef HICE_EXPRESSION_H
#define HICE_EXPRESSION_H

#include "device.h"

// Forward declarations
namespace op {

struct abs;
struct negative;
struct eval;
struct assign;
struct add;
//struct dot;
struct e_add;
struct multiply;
struct divide;
struct subtract;
struct mod;
struct maximum;
struct minimum;
struct sum;
struct mean;
struct norm1;
struct norm2;
template<typename TScalarType, typename BinaryOp> struct nullaryop_sleft;
template<typename TScalarType, typename BinaryOp> struct nullaryop_sright;

};

template<typename TExpr> struct Traits;

//template<typename TLhs, typename TRhs> class DotExpr;
template<typename TExpr, typename TUnaryOp> class UnaryExpr;
template<typename TExpr, typename TNullaryOp> class NullaryExpr;
template<typename TLhs, typename TRhs, typename TBinaryOp> class BinaryExpr;
template<typename TExpr, typename TReductionOP, int dim> class ReductionExpr;

enum {
  CPU = 0,
  CUDA = 1
};


template<typename TDerived>
class Expr {
    typedef typename Traits<TDerived>::ScalarType Scalar;
    typedef typename Traits<TDerived>::IndexType IndexType;
    
 public:
    TDerived& self() {
      return static_cast<TDerived&>(*this);
    }

    const TDerived& self() const {
      return static_cast<const TDerived&>(*this);
    }

    TDerived& to(int device_type, int device_idx = -1) {
      if (device_type == CPU) {
        self().to_device(Device(DeviceType::kCPU, device_idx));
      } else {
        self().to_device(Device(DeviceType::kCUDA, device_idx));
      }
      return self();
    }

    TDerived& off(int device_type, int device_idx = -1) {
      self().off_device(Device(device_type, device_idx));
      return self();
    }
    
    UnaryExpr<TDerived, op::eval> eval() const {
      return UnaryExpr<TDerived, op::eval>(self());
    }

    template<typename TUnaryOp>
    UnaryExpr<TDerived, TUnaryOp>
    make_unary_expr() const {
      return UnaryExpr<TDerived, TUnaryOp>(self());
    }

    template<typename TNullaryOp>
    NullaryExpr<TDerived, TNullaryOp>
    make_nullary_expr(const TNullaryOp& pseop) const {
      return NullaryExpr<TDerived, TNullaryOp>(self(), pseop);
    }

    template<typename TRhs, typename TBinaryOp>
    BinaryExpr<TDerived, TRhs, TBinaryOp>
    make_binary_expr(const Expr<TRhs> &rhs) const {
      return BinaryExpr<TDerived, TRhs, TBinaryOp>(self(), rhs.self());
    }

#if 0
    template<typename TRhs>
    DotExpr<TDerived, TRhs>
    make_dot_expr(const Expr<TRhs> &rhs) const {
      return DotExpr<TDerived, TRhs>(self(), rhs.self());
    }
#endif

    template<typename TReductionOP, int dim>
    ReductionExpr<TDerived, TReductionOP, dim>
    make_reduction_expr() const {
      return ReductionExpr<TDerived, TReductionOP, dim>(self());
    }

    // unary func
    UnaryExpr<TDerived, op::abs>
    abs() const {
      return make_unary_expr<op::abs>();
    }

    UnaryExpr<TDerived, op::negative>
    operator-() const {
      return make_unary_expr<op::negative>();
    }

    // pseudo binary func
    NullaryExpr<TDerived, op::nullaryop_sright<Scalar, op::multiply>>
    operator*(const Scalar rhs) const {
      return make_nullary_expr(op::nullaryop_sright<Scalar, op::multiply>(rhs));
    }

    // friend
    // PseudoBinaryExpr<const TDerived, op::pseudo_binaryop_sleft<Scalar, op::multiply>>
    // operator*(const Scalar lhs, const TDerived& rhs) {
    //   return rhs.make_pseudo_binary_expr(op::pseudo_binaryop_sleft<Scalar, op::multiply>(lhs));
    // }

    NullaryExpr<TDerived, op::nullaryop_sright<Scalar, op::divide>>
    operator/(const Scalar rhs) const {
      return make_nullary_expr(op::nullaryop_sright<Scalar, op::divide>(rhs));
    }

    // friend
    // PseudoBinaryExpr<const TDerived, op::pseudo_binaryop_sleft<Scalar, op::divide>>
    // operator/(const Scalar lhs, const TDerived& rhs) {
    //   return rhs.make_pseudo_binary_expr(op::pseudo_binaryop_sleft<Scalar, op::divide>(lhs));
    // }

    NullaryExpr<TDerived, op::nullaryop_sright<Scalar, op::e_add>>
    operator+(const Scalar rhs) const {
      return make_nullary_expr(op::nullaryop_sright<Scalar, op::e_add>(rhs));
    }

    // friend
    // PseudoBinaryExpr<const TDerived, op::pseudo_binaryop_sleft<Scalar, op::e_add>>
    // operator+(const Scalar lhs, const TDerived& rhs) {
    //   return rhs.make_pseudo_binary_expr(op::pseudo_binaryop_sleft<Scalar, op::e_add>(lhs));
    // }

    NullaryExpr<TDerived, op::nullaryop_sright<Scalar, op::subtract>>
    operator-(const Scalar rhs) const {
      return make_nullary_expr(op::nullaryop_sright<Scalar, op::subtract>(rhs));
    }

    // friend
    // PseudoBinaryExpr<const TDerived, op::pseudo_binaryop_sleft<Scalar, op::subtract>>
    // operator-(const Scalar lhs, const TDerived& rhs) {
    //   return rhs.make_pseudo_binary_expr(op::pseudo_binaryop_sleft<Scalar, op::subtract>(lhs));
    // }

    NullaryExpr<TDerived, op::nullaryop_sright<Scalar, op::mod>>
    mod(const Scalar rhs) const {
      return make_nullary_expr(op::nullaryop_sright<Scalar, op::mod>(rhs));
    }

    // binary func
    template<typename TRhs>
    BinaryExpr<TDerived, TRhs, op::multiply>
    operator*(const Expr<TRhs> &rhs) const {
      return make_binary_expr<TRhs, op::multiply>(rhs);
    }

    template<typename TRhs>
    BinaryExpr<TDerived, TRhs, op::divide>
    operator/(const Expr<TRhs> &rhs) const {
      return make_binary_expr<TRhs, op::divide>(rhs);
    }

    template<typename TRhs>
    BinaryExpr<TDerived, TRhs, op::e_add>
    operator+(const Expr<TRhs> &rhs) const {
      return make_binary_expr<TRhs, op::e_add>(rhs);
    }

    template<typename TRhs>
    BinaryExpr<TDerived, TRhs, op::subtract>
    operator-(const Expr<TRhs> &rhs) const {
      return make_binary_expr<TRhs, op::subtract>(rhs);
    }

    template<typename TRhs>
    BinaryExpr<TDerived, TRhs, op::mod>
    mod(const Expr<TRhs> &rhs) const {
      return make_binary_expr<TRhs, op::mod>(rhs);
    }

#if 0
    template<typename TRhs>
    DotExpr<TDerived, TRhs>
    dot(const Expr<TRhs> &rhs) const {
      return make_dot_expr<TRhs>(rhs);
    }
#endif

    ReductionExpr<TDerived, op::maximum, -1>  
    maximum() const {
      // -1 indicates to reduce all dimensions into a Tensor<Scalartype, 0>.
      return make_reduction_expr<op::maximum, -1>();
    }

    ReductionExpr<TDerived, op::minimum, -1>  
    minimum() const {
      // -1 indicates to reduce all dimensions into a Tensor<Scalartype, 0>.
      return make_reduction_expr<op::minimum, -1>();
    }

    ReductionExpr<TDerived, op::sum, -1>  
    sum() const {
      // -1 indicates to reduce all dimensions into a Tensor<Scalartype, 0>.
      return make_reduction_expr<op::sum, -1>();
    }

    ReductionExpr<TDerived, op::mean, -1>  
    mean() const {
      // -1 indicates to reduce all dimensions into a Tensor<Scalartype, 0>.
      return make_reduction_expr<op::mean, -1>();
    }

    ReductionExpr<TDerived, op::norm1, -1>  
    norm1() const {
      // -1 indicates to reduce all dimensions into a Tensor<Scalartype, 0>.
      return make_reduction_expr<op::norm1, -1>();
    }

    ReductionExpr<TDerived, op::norm2, -1>  
    norm2() const {
      // -1 indicates to reduce all dimensions into a Tensor<Scalartype, 0>.
      return make_reduction_expr<op::norm2, -1>();
    }
};

template<typename TExpr, typename TUnaryOp>
class UnaryExpr: public Expr<UnaryExpr<TExpr, TUnaryOp>> {
 public:
	explicit UnaryExpr(const TExpr &expr)
       : expr_(expr), device_(DeviceType::kCPU) {}

  const TExpr& expr() const { return expr_; }
  
  const Device& device() const { return device_; }

  void to_device(Device device) { 
    const_cast<TExpr &>(expr_).to_device(device);
    device_ = device;
  }

  void off_device(Device device) {
    expr_.off_device(device);
    device_ = Device(DeviceType::kCPU); 
  }

 private:
	const TExpr &expr_;
  Device device_;
};

// binary operator between tensor and scalar, in fact it is a unary operator.
template<typename TExpr, typename TNullaryOp>
class NullaryExpr: public Expr<NullaryExpr<TExpr, TNullaryOp>> {
	public:
		explicit NullaryExpr(const TExpr &expr, const TNullaryOp &nop) : expr_(expr), nop_(nop), device_(DeviceType::kCPU)  {}

    const TExpr& expr() const { return expr_; }
	
    const TNullaryOp& nop() const { return nop_; }
  
    const Device& device() const { return device_; }

    void to_device(Device device) { 
      const_cast<TExpr &>(expr_).to_device(device);
      device_ = device;
    }

    void off_device(Device device) {
      expr_.off_device(device);
      device_ = Device(DeviceType::kCPU); 
    }

	private:
		const TExpr &expr_;
		const TNullaryOp nop_;
		Device device_;
};

template<typename TLhs, typename TRhs, typename TBinaryOp>
class BinaryExpr: public Expr<BinaryExpr<TLhs, TRhs, TBinaryOp>> {
 public:
 	explicit BinaryExpr(const TLhs &lhs, const TRhs &rhs)
       : lhs_(lhs), rhs_(rhs), device_(DeviceType::kCPU) {}
 
  const TLhs& lhs() const { return lhs_; }
 
  const TRhs& rhs() const { return rhs_; }
 
  const Device& device() const { return device_; } 

  void to_device(Device device) { 
    const_cast<TLhs &>(lhs_).to_device(device);
    const_cast<TRhs &>(rhs_).to_device(device);
    device_ = device;
  }

  void off_device(Device device) {
    lhs_.off_device(device);
    rhs_.off_device(device);
    device_ = Device(DeviceType::kCPU); 
  }
 
 private:
 	const TLhs &lhs_;
 	const TRhs &rhs_;
  Device device_;
};

#if 0
template<typename TLhs, typename TRhs>
class DotExpr: public Expr<DotExpr<TLhs, TRhs>> {
	public:
		explicit DotExpr(const TLhs &lhs, const TRhs &rhs)
        : lhs_(lhs), rhs_(rhs), device_(DeviceType::kCPU)  {}

    const TLhs& lhs() const { return lhs_; }
	
    const TRhs& rhs() const { return rhs_; }
 
	const Device& device() const { return device_; } 

	void to_device(Device device) { 
		const_cast<TLhs &>(lhs_).to_device(device);
		const_cast<TRhs &>(rhs_).to_device(device);
		device_ = device;
	}

	void off_device(Device device) {
		lhs_.off_device(device);
		rhs_.off_device(device);
		device_ = Device(DeviceType::kCPU); 
	}

	private:
		const TLhs &lhs_;
		const TRhs &rhs_;
		Device device_;
};
#endif

template<typename TExpr, typename TReductionOP, int dim>
class ReductionExpr: public Expr<ReductionExpr<TExpr, TReductionOP, dim>> {
	public:
		explicit ReductionExpr(const TExpr &expr) : expr_(expr), device_(DeviceType::kCPU)  {}

    const TExpr& expr() const { return expr_; }
 
	const Device& device() const { return device_; } 

	void to_device(Device device) { 
		const_cast<TExpr &>(expr_).to_device(device);
		device_ = device;
	}

	void off_device(Device device) {
		expr_.off_device(device);
		device_ = Device(DeviceType::kCPU); 
	}

	private:
		const TExpr &expr_;
		Device device_;
};

#endif
