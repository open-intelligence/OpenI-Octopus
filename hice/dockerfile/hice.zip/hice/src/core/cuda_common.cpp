#include "cuda_common.h"

int cuda_get_device_idx(const void* ptr) {
  cudaPointerAttributes attr;
  cudaError_t err = cudaPointerGetAttributes(&attr, ptr);
  if (err == cudaErrorInvalidValue) {
    // Clear the last error state
    err = cudaGetLastError();
    return -1;
  }
  if (attr.memoryType == cudaMemoryTypeHost) {
    return -1;
  }

  return attr.device;
}

int cuda_get_num_devices() {
  static int count = -1;
  if (count < 0) {
    auto err = cudaGetDeviceCount(&count);
    switch (err) {
      case cudaSuccess:
        // Everything is good.
        break;
      case cudaErrorNoDevice:
        std::cerr << "Failed to get the number of GPU devices: "
                  << cudaGetErrorString(err)
                  << std::endl;
        assert(err == cudaSuccess);
        //break;
      case cudaErrorInsufficientDriver:
        std::cerr << "Failed to get the number of GPU devices: "
                  << cudaGetErrorString(err)
                  << std::endl;
        assert(err == cudaSuccess);
        //break;
      case cudaErrorInitializationError:
        std::cerr << "Failed to get the number of GPU devices: "
                  << cudaGetErrorString(err)
                  << std::endl;
        assert(err == cudaSuccess);
        //break;
      case cudaErrorUnknown:
        std::cerr << "Failed to get the number of GPU devices: "
                  << cudaGetErrorString(err)
                  << std::endl;
        assert(err == cudaSuccess);
        //break;
      case cudaErrorMemoryAllocation:
        std::cerr << "Failed to get the number of GPU devices: "
                  << cudaGetErrorString(err)
                  << std::endl;
        assert(err == cudaSuccess);
        //break;
      default:
        std::cerr << "Failed to get the number of GPU devices: "
                  << cudaGetErrorString(err)
                  << std::endl;
        assert(err == cudaSuccess);
    }
  }
  return count;
}
