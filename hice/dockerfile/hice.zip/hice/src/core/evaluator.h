#ifndef HICE_EVALUATOR_H
#define HICE_EVALUATOR_H

#include "expression.h"
#include "expression_traits.h"
#include "operator.h" 
#include "tensor.h"
#include "cuda_eval.cuh"
#include <cstdio>

// General evaluator
template<typename TExpr> class Evaluator {};

// Unary evaluators
template<typename TExpr, typename TUnaryOp>
class Evaluator<UnaryExpr<TExpr, TUnaryOp>> {
 public:
  typedef UnaryExpr<TExpr, TUnaryOp> ExprType;
  typedef typename Traits<ExprType>::ShapeType ShapeType;
  typedef typename Traits<ExprType>::IndexType IndexType;
  typedef typename Traits<ExprType>::ScalarType ScalarType;
  typedef typename Traits<ExprType>::ResultType ResultType;

  explicit Evaluator(const ExprType &expr) : eval_(expr.expr()), result_(), device_(expr.device()) {
    result_.resize(shape());
  }

  const ShapeType& shape() const {
    return eval_.shape();
  }

  const Device& device() const {
    return device_;
  }

  // this function will be called if there will be element-wise operation in run().
  void eval_sub_expr_to_support_element_wise(){
    eval_.eval_sub_expr_to_support_element_wise();
  }

  ResultType& run() {
    result_.resize(shape());
    eval_sub_expr_to_support_element_wise();
    
    if (device_.is_cpu()) {
      // std::cout<<"Evaluator<UnaryExpr<TExpr, TUnaryOp>>.run()"<<std::endl;
      MetaEval<Evaluator<ExprType>, ResultType, 
               ScalarType, IndexType, DeviceType::kCPU>::run((*this), result_);
    }else if (device_.is_cuda()) {
      MetaEval<Evaluator<ExprType>, ResultType, 
               ScalarType, IndexType, DeviceType::kCUDA>::run((*this), result_);
    }else {

    }
    // size_t num_eles = result_.size();
    // ScalarType* r_data = result_.data();
    // for (IndexType i=0; i<num_eles; ++i){
    //   r_data[i] = this->calc(i);
    // }

    return result_;
  }

  // calculate
  HICE_DEVICE_FUNC
  ScalarType calc(IndexType i){
    // printf("Evaluator<Unary>::calc(i) = calc(%d)\n", i);
    return TUnaryOp::apply(eval_.calc(i));
  }

 private:
  Evaluator<TExpr> eval_;
  ResultType result_;
  Device device_;
};

template<typename TExpr>
class Evaluator<UnaryExpr<TExpr, op::eval>> {
public:
  typedef UnaryExpr<TExpr, op::eval> ExprType;
  typedef typename Traits<ExprType>::ShapeType ShapeType;
  typedef typename Traits<ExprType>::IndexType IndexType;
  typedef typename Traits<ExprType>::ScalarType ScalarType;
  typedef typename Traits<ExprType>::ResultType ResultType;

  explicit Evaluator(const ExprType &expr) : eval_(expr.expr()), result_(), device_(expr.device()) {}

  const ShapeType& shape() const {
    return eval_.shape();
  }

  const Device& device() const {
    return device_;
  }

  void eval_sub_expr_to_support_element_wise(){
    this->run();
  }

  ResultType& run() {
    result_.resize(shape());
    op::eval::apply(eval_.run(), result_);
    return result_;
  }

  // calculate
  HICE_DEVICE_FUNC
  ScalarType calc(IndexType i){
    ScalarType* data = NULL;
    if (device_.is_cpu()) {
      data = result_.data();
    }else if (device_.is_cuda()) {
      data = result_.device_data();
    }else {

    }
    return data[i];
  }

private:
  Evaluator<TExpr> eval_;
  ResultType result_;
  Device device_;
};

template<typename TScalarType, int ndim, 
         typename TIndexType, StorageType stype>
class Evaluator<Tensor<TScalarType, ndim, TIndexType, stype>> {
 public:
  typedef Tensor<TScalarType, ndim, TIndexType, stype> ExprType;
  typedef typename Traits<ExprType>::ShapeType ShapeType;
  typedef typename Traits<ExprType>::IndexType IndexType;
  typedef typename Traits<ExprType>::ScalarType ScalarType;
  typedef typename Traits<ExprType>::ResultType ResultType;

  explicit Evaluator(const ExprType &tensor)
      : result_(const_cast<ResultType&>(tensor)), device_(tensor.device()) {
        // std::cout<<"In Evaluator<Tensor>::Evaluator."<<std::endl;
        // std::cout<<result_<<std::endl;
      }

  const ShapeType& shape() const {
    return result_.shape();
  }

  const Device& device() const {
    return device_;
  }

  // do nothing
  void eval_sub_expr_to_support_element_wise(){}

  ResultType& run() {
    // std::cout<<"Evaluator<Tensor>.run()"<<std::endl;
    return result_;
  }

  // calculate
  HICE_DEVICE_FUNC
  ScalarType calc(IndexType i){
    ScalarType* data = NULL;
    if (device_.is_cpu()) {
      data = result_.data();
    }else if (device_.is_cuda()) {
      data = result_.device_data();
      // if (i<2){
      //   printf("Eval<T>.calc(%d).data[i] = %lf\n", i, data[i]);
      // }
    }else {

    }
    return data[i];
    // return result_.at(i);
  }

 private:
  ResultType result_;
  Device device_;
};

template<typename TExpr, typename TNullaryOp>
class Evaluator<NullaryExpr<TExpr, TNullaryOp>> {
 public:
  typedef NullaryExpr<TExpr, TNullaryOp> ExprType;
  typedef typename Traits<ExprType>::ShapeType ShapeType;
  typedef typename Traits<ExprType>::IndexType IndexType;
  typedef typename Traits<ExprType>::ScalarType ScalarType;
  typedef typename Traits<ExprType>::ResultType ResultType;

  explicit Evaluator(const ExprType &expr) :  eval_(expr.expr()),
                                              nop_(const_cast<TNullaryOp&>(expr.nop())),
                                              result_(),
                                              device_(expr.device()) {}

  const ShapeType& shape() const {
    return eval_.shape();
  }

  const Device& device() const {
    return device_;
  }

  void eval_sub_expr_to_support_element_wise(){
    eval_.eval_sub_expr_to_support_element_wise();
  }

  ResultType& run() {
    result_.resize(shape());
    eval_sub_expr_to_support_element_wise();

    if (device_.is_cpu()) {
      // std::cout<<"Evaluator<UnaryExpr<TExpr, TUnaryOp>>.run()"<<std::endl;
      MetaEval<Evaluator<ExprType>, ResultType, 
               ScalarType, IndexType, DeviceType::kCPU>::run((*this), result_);
    }else if (device_.is_cuda()) {
      MetaEval<Evaluator<ExprType>, ResultType, 
               ScalarType, IndexType, DeviceType::kCUDA>::run((*this), result_);
    }else {

    }

    // size_t num_eles = result_.size();
    // ScalarType* r_data = result_.data();
    // for (IndexType i=0; i<num_eles; ++i){
    //   r_data[i] = this->calc(i);
    // }

    return result_;
  }

  // calculate
  HICE_DEVICE_FUNC
  ScalarType calc(IndexType i){
    return nop_.apply(eval_.calc(i));
  }

 private:
  Evaluator<TExpr> eval_;
  TNullaryOp nop_;
  ResultType result_;
  Device device_;
};

template<typename TLhs, typename TRhs, typename TBinaryOp>
class Evaluator<BinaryExpr<TLhs, TRhs, TBinaryOp>> {
 public:
  typedef BinaryExpr<TLhs, TRhs, TBinaryOp> ExprType;
  static const int kDim = Traits<ExprType>::kDim;
  static const int kLhsDim = Traits<TLhs>::kDim;
  static const int kRhsDim = Traits<TRhs>::kDim;
  typedef typename Traits<ExprType>::ShapeType ShapeType;
  typedef typename Traits<ExprType>::IndexType IndexType;
  typedef typename Traits<ExprType>::ScalarType ScalarType;
  typedef typename Traits<ExprType>::ResultType ResultType;

  explicit Evaluator(const ExprType &expr)  : lhs_eval_(expr.lhs()),
                                              rhs_eval_(expr.rhs()),
                                              result_(),
                                              shape_(),
                                              device_(expr.device()),
                                              evaled_(false)
  {
    const IndexType* lhs_dims_ = lhs_eval_.shape().data();
    const IndexType* rhs_dims_ = rhs_eval_.shape().data();
    if(kLhsDim!=0)
      shape_.reshape(lhs_dims_);
    else
      shape_.reshape(rhs_dims_);
    result_.resize(shape());
  }

  const ShapeType& shape() const {
    return shape_;
  }

  const Device& device() const {
    return device_;
  }

  void eval_sub_expr_to_support_element_wise(){
    // std::cout<<"lhs_eval_.eval_sub*() begin"<<std::endl;
    lhs_eval_.eval_sub_expr_to_support_element_wise();
    // std::cout<<"lhs_eval_.eval_sub*() end"<<std::endl;
    // std::cout<<"rhs_eval_.eval_sub*() begin"<<std::endl;
    rhs_eval_.eval_sub_expr_to_support_element_wise();
    // std::cout<<"rhs_eval_.eval_sub*() end"<<std::endl;
    // if(kDim==-1)
    //   std::cout<<"Dim error: Invalid assignment operation."<<std::endl;
    bool need_evaled = (kLhsDim==0 && kRhsDim!=0) || (kLhsDim!=0 && kRhsDim==0);
    if(need_evaled){

      if (device_.is_cpu()) {
        MetaEval<Evaluator<ExprType>, ResultType, 
                ScalarType, IndexType, DeviceType::kCPU>::run((*this), result_);
      }else if (device_.is_cuda()) {
        // std::cout<<"Evaluator<BinaryExpr>>.is_cuda()"<<std::endl;
        MetaEval<Evaluator<ExprType>, ResultType, 
                ScalarType, IndexType, DeviceType::kCUDA>::run((*this), result_);
      }else {

      }

      // size_t num_eles = result_.size();
      // ScalarType* r_data = result_.data();
      // for (IndexType i=0; i<num_eles; ++i){
      //   r_data[i] = this->calc(i);
      // }
      evaled_ = true;
    }
  }

  ResultType& run() {
    eval_sub_expr_to_support_element_wise();
    if(!evaled_){

      if (device_.is_cpu()) {
        MetaEval<Evaluator<ExprType>, ResultType, 
                ScalarType, IndexType, DeviceType::kCPU>::run((*this), result_);
      }else if (device_.is_cuda()) {;
        MetaEval<Evaluator<ExprType>, ResultType, 
                ScalarType, IndexType, DeviceType::kCUDA>::run((*this), result_);
      }else {

      }

      // size_t num_eles = result_.size();
      // ScalarType* r_data = result_.data();
      // for (IndexType i=0; i<num_eles; ++i){
      //   r_data[i] = this->calc(i);
      // }
    }
    return result_;
  }

  // calculate, two parameters to keep inline(avoid judgement as much as possible).
  HICE_DEVICE_FUNC
  ScalarType calc(IndexType i){
    const int lhs_param_handler = (kLhsDim==0 ? 0 : 1);
    const int rhs_param_handler = (kRhsDim==0 ? 0 : 1);
    return TBinaryOp::apply(lhs_eval_.calc(i*lhs_param_handler), rhs_eval_.calc(i*rhs_param_handler));
  }

 private:
  Evaluator<TLhs> lhs_eval_;
  Evaluator<TRhs> rhs_eval_;
  ResultType result_;
  ShapeType shape_;
  Device device_;
  bool evaled_;
};

template<typename TLhs, typename TRhs>
class Evaluator<BinaryExpr<TLhs, TRhs, op::assign>> {
 public:
  typedef BinaryExpr<TLhs, TRhs, op::assign> ExprType;
  typedef typename Traits<ExprType>::ShapeType ShapeType;
  typedef typename Traits<ExprType>::ResultType ResultType;

  explicit Evaluator(const ExprType &expr)
      : lhs_eval_(expr.lhs()), 
        rhs_eval_(expr.rhs()), 
        // result_(const_cast<ResultType&>(lhs_eval_.run())),
        // result_(lhs_eval_.run()),
        result_(const_cast<ResultType&>(expr.lhs())),
        device_(expr.device()) {}

  void run() {
    op::assign::apply(rhs_eval_.run(), result_);
  }

 private:
  Evaluator<TLhs> lhs_eval_;
  Evaluator<TRhs> rhs_eval_;
  ResultType& result_;
  Device device_;
};

#if 0
template<typename TScalarType1, typename TIndexType1, 
         typename TScalarType2, typename TIndexType2,
         StorageType stype>
class Evaluator<DotExpr<Tensor<TScalarType1, 1, TIndexType1, stype>, 
                           Tensor<TScalarType2, 1, TIndexType2, stype>>> {
 public:
  typedef Tensor<TScalarType1, 1, TIndexType1, stype> TLhs;
  typedef Tensor<TScalarType2, 1, TIndexType2, stype> TRhs;
  typedef DotExpr<TLhs, TRhs> ExprType;
  static const int kDim = Traits<ExprType>::kDim;
  typedef typename Traits<ExprType>::IndexType IndexType;
  typedef typename Traits<ExprType>::ShapeType ShapeType;
  typedef typename Traits<ExprType>::ResultType ResultType;
  typedef typename Traits<ExprType>::ScalarType ScalarType;

  explicit Evaluator(const ExprType &expr)
      : lhs_eval_(expr.lhs()), rhs_eval_(expr.rhs()), 
        result_(), shape_() {}

  const ShapeType& shape() const {
    return shape_;
  }

  void eval_sub_expr_to_support_element_wise(){
    this->run();
  }

  ResultType& run() {
    op::dot::apply(lhs_eval_.run(), rhs_eval_.run(), result_);
    return result_;
  }

  // calculate
  ScalarType calc(IndexType i){
    return result_.at(i);
  }

 private:
  Evaluator<TLhs> lhs_eval_;
  Evaluator<TRhs> rhs_eval_;
  ResultType result_;
  ShapeType shape_;
};

template<typename TScalarType1, typename TIndexType1, 
         typename TScalarType2, typename TIndexType2,
         StorageType stype>
class Evaluator<DotExpr<Tensor<TScalarType1, 2, TIndexType1, stype>, 
                           Tensor<TScalarType2, 1, TIndexType2, stype>>> {
 public:
  typedef Tensor<TScalarType1, 2, TIndexType1, stype> TLhs;
  typedef Tensor<TScalarType2, 1, TIndexType2, stype> TRhs;
  typedef DotExpr<TLhs, TRhs> ExprType;
  static const int kDim = Traits<ExprType>::kDim;
  typedef typename Traits<ExprType>::IndexType IndexType;
  typedef typename Traits<ExprType>::ShapeType ShapeType;
  typedef typename Traits<ExprType>::ResultType ResultType;
  typedef typename Traits<ExprType>::ScalarType ScalarType;

  explicit Evaluator(const ExprType &expr) 
      : lhs_eval_(expr.lhs()), rhs_eval_(expr.rhs()), 
        result_(), shape_(lhs_eval_.shape().dim(0)) {}

  const ShapeType& shape() const {
    return shape_;
  }

  void eval_sub_expr_to_support_element_wise(){
    this->run();
  }

  ResultType& run() {
    result_.resize(shape());
    op::dot::apply(lhs_eval_.run(), rhs_eval_.run(), result_);
    return result_;
  }

  // calculate
  ScalarType calc(IndexType i){
    return result_.at(i);
  }

 private:
  Evaluator<TLhs> lhs_eval_;
  Evaluator<TRhs> rhs_eval_;
  ResultType result_;
  ShapeType shape_;
};

template<typename TScalarType1, typename TIndexType1, 
         typename TScalarType2, typename TIndexType2,
         StorageType stype>
class Evaluator<DotExpr<Tensor<TScalarType1, 2, TIndexType1, stype>, 
                           Tensor<TScalarType2, 2, TIndexType2, stype>>> {
 public:
  typedef Tensor<TScalarType1, 2, TIndexType1, stype> TLhs;
  typedef Tensor<TScalarType2, 2, TIndexType2, stype> TRhs;
  typedef DotExpr<TLhs, TRhs> ExprType;
  static const int kDim = Traits<ExprType>::kDim;
  typedef typename Traits<ExprType>::IndexType IndexType;
  typedef typename Traits<ExprType>::ShapeType ShapeType;
  typedef typename Traits<ExprType>::ResultType ResultType;
  typedef typename Traits<ExprType>::ScalarType ScalarType;

  explicit Evaluator(const ExprType &expr) 
      : lhs_eval_(expr.lhs()), rhs_eval_(expr.rhs()), 
        result_(), shape_(lhs_eval_.shape().dim(0), rhs_eval_.shape().dim(1)) {}

  const ShapeType& shape() const {
    return shape_;
  }

  void eval_sub_expr_to_support_element_wise(){
    this->run();
  }

  ResultType& run() {
    result_.resize(shape());
    op::dot::apply(lhs_eval_.run(), rhs_eval_.run(), result_);
    return result_;
  }

  // calculate
  ScalarType calc(IndexType i){
    return result_.at(i);
  }

 private:
  Evaluator<TLhs> lhs_eval_;
  Evaluator<TRhs> rhs_eval_;
  ResultType result_;
  ShapeType shape_;
};
#endif

// Reduction Evaluators
template<typename TExpr, typename TReductionOp, int dim>
class Evaluator<ReductionExpr<TExpr, TReductionOp, dim>> {
 public:
  typedef ReductionExpr<TExpr, TReductionOp, dim> ExprType;
  typedef typename Traits<ExprType>::ShapeType ShapeType;
  typedef typename Traits<ExprType>::IndexType IndexType;
  typedef typename Traits<ExprType>::ScalarType ScalarType;
  typedef typename Traits<ExprType>::ResultType ResultType;

  explicit Evaluator(const ExprType &expr) : eval_(expr.expr()), result_(), device_(expr.device()) {}

  const ShapeType& shape() const {
    return eval_.shape();
  }

  const Device& device() const {
    return device_;
  }

  void eval_sub_expr_to_support_element_wise(){
    this->run();
  }

  ResultType& run() {
    // result_.resize(shape());
    TReductionOp::apply(eval_.run(), result_, dim);
    return result_;
  }

  // calculate
  HICE_DEVICE_FUNC
  ScalarType calc(IndexType i){
    ScalarType* data = NULL;
    if (device_.is_cpu()) {
      data = result_.data();
    }else if (device_.is_cuda()) {
      data = result_.device_data();
    }else {

    }
    return data[i];
  }

 private:
  Evaluator<TExpr> eval_;
  ResultType result_;
  Device device_;
};
#endif
