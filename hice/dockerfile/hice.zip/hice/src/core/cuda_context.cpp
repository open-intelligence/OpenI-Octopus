#include "cuda_context.h"

CUDAContext::CUDAContext(const int gpu_idx) {
  if (gpu_idx == -1) 
    cudaGetDevice(&gpu_idx_);
  else 
    gpu_idx_ = gpu_idx;
  static CUDAInitializer cuda_initializer;
}

CUDAObjects& CUDAContext::cuda_objects() {
  static thread_local CUDAObjects cuda_objects_;
  return cuda_objects_;
}

void CUDAContext::initialize() {}

cudaStream_t CUDAObjects::stream(int gpu_idx, int stream_idx) {
  std::vector<cudaStream_t>& gpu_streams = cuda_streams_[gpu_idx];
  if (gpu_streams.size() <= (unsigned)stream_idx) {
    gpu_streams.resize(stream_idx + 1, nullptr);
  }
  if (!gpu_streams[stream_idx]) {
    DeviceGuard device_guard(gpu_idx);
    cudaStreamCreateWithFlags(&gpu_streams[stream_idx], 
        cudaStreamNonBlocking);
  }
  return gpu_streams[stream_idx];
}

cublasHandle_t CUDAObjects::cublas_handle(int gpu_idx, int stream_idx) {
  std::vector<cublasHandle_t>& gpu_handles = cublas_handles_[gpu_idx];
  if (gpu_handles.size() <= (unsigned)stream_idx) {
    gpu_handles.resize(stream_idx + 1, nullptr);
  }
  if (!gpu_handles[stream_idx]) {
    DeviceGuard device_guard(gpu_idx);
    cublasCreate(&gpu_handles[stream_idx]);
    cublasSetPointerMode(
        gpu_handles[stream_idx], CUBLAS_POINTER_MODE_HOST);
        //gpu_handles[stream_idx], CUBLAS_POINTER_MODE_DEVICE);
    cublasSetStream(gpu_handles[stream_idx], stream(gpu_idx, stream_idx));
  }

  return gpu_handles[stream_idx];
}

#ifdef HICE_USE_CUDNN
cudnnHandle_t CUDAObjects::cudnn_handle(int gpu_idx, int stream_idx) {
  DeviceGuard device_guard(gpu_idx);
  vector<cudnnHandle_t>& cudnn_handles = cudnn_handles_[gpu_idx];
  if (cudnn_handles.size() <= (unsigned)stream_idx) {
    cudnn_handles.resize(stream_idx + 1, nullptr);
  }
  if (!cudnn_handles[stream_idx]) {
    cudnnCreate(&cudnn_handles[stream_idx]);
    cudnnSetStream(cudnn_handles[stream_idx], stream(gpu_idx, stream_idx));
  }
  return cudnn_handles[stream_idx];
}
#endif // HICE_USE_CUDNN

CUDAContext* cuda_context(Device gpu) {
  static DeviceContext *dev_ctx = DeviceContextRegister::singleton().get_device_context(gpu);
  return static_cast<CUDAContext *>(dev_ctx);
}

namespace {
  static CUDAContextRegisterProxy g_cuda_contexts;
} // namesapce

