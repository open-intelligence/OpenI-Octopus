#ifndef HICE_CONTEXT_H
#define HICE_CONTEXT_H

#include "cpu_context.h"
#include "cuda_context.h"
#include "macro.h"

DeviceContext* get_context(Device dev);

DeviceContext* create_context(Device dev);

void destory_context(Device dev, DeviceContext *dev_ctx);

#endif
