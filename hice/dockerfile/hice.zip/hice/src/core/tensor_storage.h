#ifndef HICE_TENSOR_STORAGE_H
#define HICE_TENSOR_STORAGE_H

#include <cstddef>
#include "context.h"
#include "tensor_shape.h"

enum class StorageType {
  kDense = 0,
  kCSR = 1
};

template<typename TScalarType, int ndim, typename TIndexType, StorageType stype>
class TensorStorage {};

template<typename TScalarType, int ndim, typename TIndexType>
class TensorStorage<TScalarType, ndim, TIndexType, StorageType::kDense> {
 public:
  typedef TScalarType Scalar;
  typedef TIndexType Index;
  typedef TensorShape<Index, ndim> Shape;
  typedef TensorStorage<Scalar, ndim, Index, StorageType::kDense> Self;

  TensorStorage()
      : alloc_(cpu_allocator()), 
        shape_(), device_(DeviceType::kCPU),
        data_(nullptr), dev_data_(nullptr) {
    if (ndim == 0) {
      data_ = alloc_->allocate_objects<Scalar>(1);
    }
  }

  explicit TensorStorage(const array<Index, ndim>& shape)
      : alloc_(cpu_allocator()), 
        shape_(shape), device_(DeviceType::kCPU),
        data_(nullptr), dev_data_(nullptr) {
    if (ndim == 0) {
      data_ = alloc_->allocate_objects<Scalar>(1);
    } else {
      data_ = alloc_->allocate_objects<Scalar>(size());
    }
  }

  template <typename... TIndexTypes>
  TensorStorage(Index first_dim, TIndexTypes... other_dims)
      : TensorStorage(array<Index, ndim>{{first_dim, other_dims...}}) {
  }
  
  TensorStorage(const Self& other)
      : alloc_(other.alloc_),
        shape_(other.shape_),
        device_(other.device_),
        data_(nullptr),
        dev_data_(nullptr) {
    // Step one: other device space -> other host space
    //const_cast<const&>(other).copy_to_host(other.device_, dev_data_, size(), data_);

    // Step two: other host space -> this host space
    std::size_t data_size = size();
    data_ = alloc_->allocate_objects<Scalar>(data_size);
    if (is_simple_type<Scalar>::value) {
      std::ptrdiff_t bytes = (std::ptrdiff_t)(other.data_ + data_size) 
        - (std::ptrdiff_t)other.data_;
      if(bytes == 0) return;
      std::memcpy(data_, other.data_, bytes);
    } else { 
      std::copy(other.data_, other.data_ + data_size, data_);
    }

    // Step three: other device space -> this device space
    if (other.dev_data_) {
      dev_data_ = allocate_device_space(device_, data_size);
      DeviceContext *dev_ctx = get_context(device_);
      if (device_.is_cuda()) {
        CUDAContext *cuda_ctx = static_cast<CUDAContext *>(dev_ctx);
        cuda_ctx->copy_objects(other.dev_data_, data_size, dev_data_, CopyDirection::kD2D);
      }
    }
  }

  Self& operator=(Self other) {
    swap(other);
    return *this;
  }

  ~TensorStorage() {
    //std::cout << "tensor storage dtor begin" << std::endl;
    std::size_t data_size = size();
    deallocate_device_space(device_, dev_data_, data_size);
    alloc_->deallocate_objects<Scalar>(data_, data_size);
    //std::cout << "tensor storage dtor end" << std::endl;
  }

  void swap(Self &other) {
    std::swap(alloc_, other.alloc_);
    std::swap(shape_, other.shape_);
    std::swap(device_, other.device_);
    std::swap(data_, other.data_);
    std::swap(dev_data_, other.dev_data_);
  }

  HICE_DEVICE_FUNC Scalar* data() { return data_; }
  HICE_DEVICE_FUNC const Scalar* data() const { return data_; }

  HICE_DEVICE_FUNC Scalar* device_data() { return dev_data_; }
  HICE_DEVICE_FUNC const Scalar* device_data() const { return dev_data_; }

  const Device& device() const { return device_; }

  void to_device(Device dev) { 
    if (device_ != dev) {
      std::size_t data_size = size();
      if (device_.is_cpu() && dev.is_cuda()) {
        // std::cout << "data_size: " << data_size << std::endl;
        //std::cout << "to cuda begin" << std::endl;
        dev_data_ = allocate_device_space(dev, data_size);
        copy_to_device(dev, data_, data_size, dev_data_);
        //std::cout << "to cuda end" << std::endl;
      } 
      if (device_.is_cuda() && dev.is_cpu()) {
        //std::cout << "to cpu begin" << std::endl;
        copy_to_host(dev, dev_data_, data_size, data_);
        deallocate_device_space(dev, dev_data_, data_size);
        //std::cout << "to cpu end" << std::endl;
      } 
      device_ = dev; 
    }
  }

  void to_host() { 
    if (!device_.is_cpu()) {
      // std::cout << "to host begin" << std::endl;
      copy_to_host(device_, dev_data_, size(), data_);
      // std::cout << "to host end" << std::endl;
    }
  }

  void off_device(Device dev) { 
    if (device_ == dev) {
      std::size_t data_size = size();
      if (!dev.is_cpu()) {
        copy_to_host(dev, dev_data_, data_size, data_);
        deallocate_device_space(dev, dev_data_, data_size);
      }
      device_ = Device(DeviceType::kCPU); 
    }
  }

  const Shape& shape() const {return shape_;}
  Shape& shape() {return shape_;}
  std::size_t size() const { return shape_.size(); }

  // For now, this doesn't copy the original data
  void resize(const array<Index, ndim>& new_shape) {
    Index new_size = Index(1);
    if(new_shape.size()==0)
      new_size=0;
    else{
      for (int i = 0; i < ndim; ++i) {
        new_size *= new_shape[i];
      }
    }
    const std::size_t cur_size = size();
    if(new_size != cur_size) {
      alloc_->deallocate_objects<Scalar>(data_, cur_size);
      if (new_size)
        data_ = alloc_->allocate_objects<Scalar>(new_size);
      else if (ndim == 0)
        data_ = alloc_->allocate_objects<Scalar>(1);
      else 
        data_ = 0;
      shape_ = new_shape;
    }
    // Initialize to 0
    memset(data_, 0, new_size * sizeof(Scalar));
    shape_ = new_shape;
  }

  template<typename... TIndexTypes>
  const Scalar& at(Index first_idx, Index second_idx, TIndexTypes... other_idxs) const {
    return at(array<Index, ndim>{{first_idx, second_idx, other_idxs...}});
  }

  const Scalar& at(const array<Index, ndim>& indices) const {
    return data_[shape_.linearize(indices)];
  }

  const Scalar& at() const {
    return data_[0];
  }

  HICE_DEVICE_FUNC
  const Scalar& at(Index idx) const {
    return data_[idx];
  }

  template<typename... TIndexTypes>
  Scalar& at(Index first_idx, Index second_idx, TIndexTypes... other_idxs) {
    return at(array<Index, ndim>{{first_idx, second_idx, other_idxs...}});
  }

  Scalar& at(const array<Index, ndim>& indices) {
    return data_[shape_.linearize(indices)];
  }

  Scalar& at() { return data_[0]; }

  HICE_DEVICE_FUNC
  Scalar& at(Index idx) {
    return data_[idx];
  }

  template<typename... TIndexTypes>
  const Scalar& operator()(Index first_idx, Index second_idx, TIndexTypes... other_idxs) const {
    return this->operator()(array<Index, ndim>{{first_idx, second_idx, other_idxs...}});
  }

  const Scalar& operator()(const array<Index, ndim>& indices) const {
    return at(indices);
  }

  const Scalar& operator()() const {
    return at();
  }

  const Scalar& operator()(Index idx) const {
    return at(idx);
  }

  template<typename... TIndexTypes>
  Scalar& operator()(Index first_idx, Index second_idx, TIndexTypes... other_idxs) {
    return this->operator()(array<Index, ndim>{{first_idx, second_idx, other_idxs...}});
  }

  Scalar& operator()(const array<Index, ndim>& indices) {
    return at(indices);
  }

  Scalar& operator()() {
    return at();
  }

  Scalar& operator()(Index idx) {
    return at(idx);
  }

 private:
  Scalar* allocate_device_space(Device &dev, std::size_t size) {
    Scalar *dev_data = nullptr;
    DeviceContext *dev_ctx = get_context(dev);
    if (dev.is_cuda()) {
      CUDAContext *cuda_ctx = static_cast<CUDAContext *>(dev_ctx);
      dev_data = cuda_ctx->allocate_objects<Scalar>(size);
    }
    return dev_data;
  }

  void deallocate_device_space(Device dev, Scalar *dev_data, std::size_t size) {
    if (dev_data) {
      DeviceContext *dev_ctx = get_context(dev);
      if (dev.is_cuda()) {
        CUDAContext *cuda_ctx = static_cast<CUDAContext *>(dev_ctx);
        cuda_ctx->deallocate_objects<Scalar>(dev_data, size);
        dev_data = nullptr;
      }
    }
  }

  void copy_to_device(Device dev, Scalar *data, std::size_t size, Scalar *dev_data) {
    if (data && dev_data) {
      DeviceContext *dev_ctx = get_context(dev);
      if (dev.is_cuda()) {
        CUDAContext *cuda_ctx = static_cast<CUDAContext *>(dev_ctx);
        cuda_ctx->copy_objects(data, size, dev_data, CopyDirection::kH2D);
      }
    }
  }

  void copy_to_host(Device dev, Scalar *dev_data, std::size_t size, Scalar *data) {
    if (dev_data && data) {
      DeviceContext *dev_ctx = get_context(dev);
      if (dev.is_cuda()) {
        // std::cout << "copy_to_host begin" << std::endl;
        CUDAContext *cuda_ctx = static_cast<CUDAContext *>(dev_ctx);
        cuda_ctx->copy_objects(dev_data, size, data, CopyDirection::kD2H);
        // std::cout << "copy_to_host end" << std::endl;
      }
    }
  }

  Shape shape_;
  Device device_;
  CPUAllocator *alloc_;
  Scalar *data_;
  Scalar *dev_data_;
};

//template<typename TScalarType, int ndim, typename TIndexType>
//class TensorStorage<TScalarType, ndim, TIndexType, StorageType::kCSR> {
//};


#if 0
template<typename TScalarType, typename TShape, StorageType s>
struct TensorStorage;

template<typename TScalarType, typename TShape>
struct TensorStroage<TScalarType, TShape, StroageType::kDense> {
  typedef DenseStorage<TScalarType, TShape> type;
}

template<typename TScalarType, typename TShape>
struct TensorStroage<TScalarType, TShape, StroageType::kCSR> {
  typedef CSRStorage<TScalarType, TShape> type;
}
#endif

#endif
