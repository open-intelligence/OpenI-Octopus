#include "cpu_context.h"

void CPUContext::copy_bytes(const void* src, size_t nbytes,
    void* dst, CopyDirection direction) {
  if (nbytes == 0) return;
  if (direction == CopyDirection::kH2H) {
    memcpy(dst, src, nbytes);
  } else if (direction == CopyDirection::kH2D) {
    Device device(DeviceType::kCUDA, cuda_get_device_idx(dst));
    DeviceContext *cuda_ctx = cuda_context(device);
    cuda_ctx->copy_bytes(src, nbytes, dst, direction);
  } else if (direction == CopyDirection::kD2H) {
    Device device(DeviceType::kCUDA, cuda_get_device_idx(dst));
    DeviceContext *cuda_ctx = cuda_context(device);
    cuda_ctx->copy_bytes(src, nbytes, dst, direction);
  } else {
    throw std::runtime_error("Unsupported data transfer on CPU");
  }
}

namespace {

static CPUContext cpu_context;
REGISTER_CPUCONTEXT(&cpu_context);

} // namespace

CPUContext* cpu_context() {
  Device cpu(DeviceType::kCPU);
  static DeviceContext *dev_ctx = DeviceContextRegister::singleton().get_device_context(cpu);
  return static_cast<CPUContext *>(dev_ctx);
}
