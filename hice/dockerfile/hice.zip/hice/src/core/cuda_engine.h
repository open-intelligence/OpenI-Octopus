#ifndef HICE_CUDA_ENGINE_H
#define HICE_CUDA_ENGINE_H

#include <iostream>
#include <cublas_v2.h>
#include "cuda_context.h"

namespace engine{
/*
template<DeviceType Td, typename TScalarType, typename TMat, typename TVec>
typename std::enable_if<is_same_device<Td, DeviceType::kCUDA>::value, void>::type
gemv(const TMat &mat, const TVec &vec, TVec &result,
    const TScalarType alpha = TScalarType(1), 
    const TScalarType beta = TScalarType(0),
    bool do_trans = false) {
  std::cout << "cuda engine" << std::endl;
  result.to_device(mat.device());
  CUDAContext *cuda_ctx = cuda_context(mat.device());
  cublasHandle_t handle = cuda_ctx->cublas_handle();
  cublasOperation_t trans = do_trans ? 
      (is_complex<TScalarType>::value ? CUBLAS_OP_C : CUBLAS_OP_T) : 
      CUBLAS_OP_N;
  const int m = mat.dim(0);
  const int n = mat.dim(1);
  const int lda = n;
  const int incx = 1;
  const int incy = 1;
  if (std::is_same<TScalarType, float>::value) {
    typedef float T;
    const T *a = (const T*)mat.device_data();
    const T *x = (const T*)vec.device_data();
    T *y = (T*)result.device_data();
    cublasStatus_t status = cublasSgemv(handle, trans, m, n,
                         (const T*)&alpha,
                         (const T*)a, lda,
                         (const T*)x, incx,
                         (const T*)&beta,
                         (T*)y, incy);
  } else if (std::is_same<TScalarType, double>::value) {
    typedef double T;
    const T *a = (const T*)mat.device_data();
    const T *x = (const T*)vec.device_data();
    T *y = (T*)result.device_data();
    cublasStatus_t status = cublasDgemv(handle, trans, m, n,
                         (const T*)&alpha,
                         (const T*)a, lda,
                         (const T*)x, incx,
                         (const T*)&beta,
                         (T*)y, incy);
  } else if (std::is_same<TScalarType, std::complex<float>>::value) {
    typedef cuFloatComplex T;
    const T *a = (const T*)mat.device_data();
    const T *x = (const T*)vec.device_data();
    T *y = (T*)result.device_data();
    cublasStatus_t status = cublasCgemv(handle, trans, m, n,
                         (const T*)&alpha,
                         (const T*)a, lda,
                         (const T*)x, incx,
                         (const T*)&beta,
                         (T*)y, incy);
  } else if (std::is_same<TScalarType, std::complex<double>>::value) {
    typedef cuDoubleComplex T;
    const T *a = (const T*)mat.device_data();
    const T *x = (const T*)vec.device_data();
    T *y = (T*)result.device_data();
    cublasStatus_t status = cublasZgemv(handle, trans, m, n,
                         (const T*)&alpha,
                         (const T*)a, lda,
                         (const T*)x, incx,
                         (const T*)&beta,
                         (T*)y, incy);
  }
  result.to_host();
}
*/

};

#endif
