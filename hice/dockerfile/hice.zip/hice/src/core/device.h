#ifndef HICE_DEVICEID_H
#define HICE_DEVICEID_H

#include <iostream>
#include "traits.h"
#include "macro.h"

enum class DeviceType {
  kCPU = 0,
  kCUDA = 1
};

template<DeviceType d1, DeviceType d2>
struct is_same_device {
  static constexpr bool value = (d1 == d2);
};

using DeviceIndex = int;

struct Device {

  Device(DeviceType type, DeviceIndex index = -1)
      : type_(type), index_(index) {}
  //Device(const Device& other)
  //    : type_(other.type_), index_(other.index_) {}

  bool operator==(const Device& other) const {
    if (is_cpu())
      return this->type_ == other.type_;
    else
      return this->type_ == other.type_ && this->index_ == other.index_;
  }

  bool operator!=(const Device& other) const { 
    return !(*this == other);
  }

  DeviceType type() const  { return type_; }

  DeviceIndex index() const  { return index_; }

  void set_index(DeviceIndex index) { index_ = index; }

  bool has_index() const  { return index_ != -1; }

  HICE_DEVICE_FUNC bool is_cpu() const  { return type_ == DeviceType::kCPU; }

  HICE_DEVICE_FUNC bool is_cuda() const  { return type_ == DeviceType::kCUDA; }


 private:
  DeviceType type_;
  DeviceIndex index_;
};

namespace std {
  template<> 
  struct less<Device> {
    bool operator() (const Device& lhs, const Device& rhs) const {
      if (lhs.type() < rhs.type()) return true;
      if (lhs.index() < lhs.index()) return true;
      return false;
    }
  };
}

std::ostream& operator<<(std::ostream& os, const Device& device);

#endif
