#include "cuda_allocator.h"

void* CUDAAllocator::allocate_bytes(size_t num_bytes, size_t alignment) {
  void *d_ptr = 0;
  cudaError_t res = cudaMalloc(&d_ptr, num_bytes);
  if (res != cudaSuccess) {
    std::cerr<< "cudaMalloc failed to allocate " << num_bytes;
    return nullptr;
  }
  return d_ptr;
}

void CUDAAllocator::deallocate_bytes(void* ptr) {
  cudaError_t res = cudaFree(ptr);
  if (res != cudaSuccess) {
    std::cerr << "cudaFree failed to free " << ptr;
  }
}

namespace {
static CUDAAllocator cuda_allocator;
REGISTER_ALLOCATOR(DeviceType::kCUDA, &cuda_allocator);

} // namespace

CUDAAllocator* cuda_allocator() {
  static Allocator* allocator = 
      AllocatorRegister::singleton().get_allocator(DeviceType::kCUDA);
  return static_cast<CUDAAllocator *>(allocator);
}
