#ifndef HICE_DEVICE_CONTEXT_H
#define HICE_DEVICE_CONTEXT_H

#include <map>
#include <mutex> 
#include "device.h"

enum class CopyDirection {
  kH2H,
  kH2D,
  kD2H,
  kD2D
};

class DeviceContext {
 public:
  virtual ~DeviceContext() {}

  virtual DeviceType device_type() const = 0;

  virtual void* allocate_bytes(std::size_t num_bytes, std::size_t alignment) = 0;

  virtual void deallocate_bytes(void* ptr) = 0;

  virtual void copy_bytes(const void* src, size_t nbytes,
                          void* dst, CopyDirection direction) = 0;

  template <typename T>
  void copy_objects(const T* src, size_t n, T* dst, CopyDirection direction) {
    copy_bytes(static_cast<const void*>(src), n * sizeof(T), 
               static_cast<void*>(dst), direction);
  }

  virtual void synchronize() = 0;
};

class DeviceContextRegister {
 public:
   static DeviceContextRegister& singleton() {
     static DeviceContextRegister dev_ctx_reg;
     return dev_ctx_reg;
   }

   void set_device_context(Device device, DeviceContext *device_context) {
     std::lock_guard<std::mutex> guard(mu_);
     device_contexts_[device] = device_context;
   } 

   DeviceContext* get_device_context(Device device) {
     return device_contexts_[device];
   }

 private:
   DeviceContextRegister() {}
   DeviceContextRegister(DeviceContextRegister const&) = delete;
   DeviceContextRegister& operator=(DeviceContextRegister const&) = delete;
   std::mutex mu_;
   std::map<Device, DeviceContext*> device_contexts_;
};

#endif
