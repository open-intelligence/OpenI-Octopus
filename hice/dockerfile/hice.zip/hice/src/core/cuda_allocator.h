#ifndef HICE_CUDA_ALLOCATOR_H
#define HICE_CUDA_ALLOCATOR_H

#include <limits>
#include <iostream>
#include <cuda.h>
#include <cuda_runtime.h>
#include "traits.h"
#include "allocator.h"

template <typename T> struct is_simple_type;

class CUDAAllocator : public Allocator {
 public:
  CUDAAllocator() {}
  ~CUDAAllocator() override {}

  void* allocate_bytes(size_t num_bytes, size_t alignment) override;
  void deallocate_bytes(void* ptr) override;

  template <typename T>
  T* allocate_objects(std::size_t num_elems) {
    if (num_elems > (std::numeric_limits<std::size_t>::max() / sizeof(T))) {
      return nullptr;
    }
    void* ptr = allocate_bytes(sizeof(T) * num_elems, kAlignment);
    return reinterpret_cast<T*>(ptr);
  }
  
  template <typename T>
  void deallocate_objects(void* ptr, std::size_t num_elems) {
    deallocate_bytes(reinterpret_cast<void *>(ptr));
  }

 private:
  CUDAAllocator(const CUDAAllocator&) = delete; 
  void operator=(const CUDAAllocator&) = delete;
};

CUDAAllocator* cuda_allocator();

#endif
