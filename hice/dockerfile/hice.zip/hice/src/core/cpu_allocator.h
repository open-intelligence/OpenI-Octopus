#ifndef HICE_CPU_ALLOCATOR_H
#define HICE_CPU_ALLOCATOR_H

#include <limits>
#include "traits.h"
#include "allocator.h"
#include "memory.h"

template <typename T> struct is_simple_type;

class CPUAllocator : public Allocator {
 public:
   CPUAllocator() {}
  ~CPUAllocator() override;

  void* allocate_bytes(size_t num_bytes, size_t alignment) override;

  void deallocate_bytes(void* ptr) override; 

  template <typename T>
  T* allocate_objects(std::size_t num_elems) {
    if (num_elems > (std::numeric_limits<std::size_t>::max() / sizeof(T))) {
      return nullptr;
    }
    void* ptr = allocate_bytes(sizeof(T) * num_elems, kAlignment);
    T* typed_ptr = reinterpret_cast<T*>(ptr);
    if (!is_simple_type<T>::value && typed_ptr) {
      for (int i = 0; i < num_elems; ++i, ++typed_ptr)
        new(typed_ptr) T();
    }
    return typed_ptr;
  }

  template <typename T>
  void deallocate_objects(T* typed_ptr, std::size_t num_elems) {
    if (typed_ptr) {
      if (!is_simple_type<T>::value) {
        for (int i = num_elems - 1; i >=0; --i, --typed_ptr)
          typed_ptr->~T();
      }
      deallocate_bytes(typed_ptr);
    }
  }

 private:
  CPUAllocator(const CPUAllocator&) = delete; 
  void operator=(const CPUAllocator&) = delete;
};

CPUAllocator* cpu_allocator();

#endif
