#ifndef HICE_CUDA_COMMON_H
#define HICE_CUDA_COMMON_H 

#include <iostream>
#include <cassert>
#include <cuda.h>
#include <cuda_runtime.h>

class DeviceGuard {
 public:
  explicit DeviceGuard(int new_device) {
    cudaGetDevice(&prev_device_);
    if (prev_device_ != new_device) {
      cudaSetDevice(new_device);
    }
  }

  ~DeviceGuard() {
    cudaSetDevice(prev_device_);
  }

 private:
  int prev_device_;
};

int cuda_get_device_idx(const void* ptr);

int cuda_get_num_devices();


#endif
