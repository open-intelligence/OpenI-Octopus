#ifndef HICE_ENGINE_H
#define HICE_ENGINE_H

enum class DeviceType;

#include "cpu_engine.h" 

#include "cuda_engine.h" 

#endif
