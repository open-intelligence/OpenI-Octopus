#include "device.h"

std::ostream& operator<<(std::ostream& os, const Device& device) {
  os << as_number(device.type());
  if (device.has_index()) {
    os << ":" << device.index();
  }
  return os;
}
