#ifndef HICE_TRAITS_H
#define HICE_TRAITS_H

#include <array>
#include <complex>
#include <type_traits>

using complex64 = std::complex<float>;
using complex128 = std::complex<double>;

template <typename T>
struct is_complex : std::false_type {};
template <>
struct is_complex<std::complex<float>> : std::true_type {};
template <>
struct is_complex<std::complex<double>> : std::true_type {};

template <typename T>
struct is_simple_type {
  static constexpr bool value =
      std::is_trivial<T>::value ||
      std::is_same<T, complex64>::value || 
      std::is_same<T, complex128>::value;
};

template <typename TEnum>
constexpr typename std::enable_if<std::is_enum<TEnum>::value, 
          typename std::underlying_type<TEnum>::type>::type 
as_number(const TEnum value) {
      return static_cast<typename std::underlying_type<TEnum>::type>(value);
}

template<typename TShape>
struct shape_size {
  static const int value = std::tuple_size<typename TShape::array>::value;
};


#endif
