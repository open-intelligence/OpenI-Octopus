#ifndef HICE_CPU_CONTEXT_H
#define HICE_CPU_CONTEXT_H

#include "cpu_allocator.h"
#include "cuda_context.h"

class CPUContext: public DeviceContext {
 public:
  ~CPUContext() override {}

  DeviceType device_type() const override {
    return DeviceType::kCPU;
  }

  void* allocate_bytes(std::size_t num_bytes, std::size_t alignment) override {
    return cpu_allocator()->allocate_bytes(num_bytes, alignment);
  }

  void deallocate_bytes(void* ptr) override {
    cpu_allocator()->deallocate_bytes(ptr);
  }

  template <typename T>
  T* allocate_objects(std::size_t num_elems) {
    return  cpu_allocator()->allocate_objects<T>(num_elems);
  }
  
  template <typename T>
  void deallocate_objects(T* typed_ptr, std::size_t num_elems) {
    cpu_allocator()->deallocate_objects<T>(typed_ptr, num_elems);
  }

  void copy_bytes(const void* src, size_t nbytes,
                  void* dst, CopyDirection direction) override;

  void synchronize() override {}
  
};

class CPUContextRegisterProxy {
 public:
  CPUContextRegisterProxy(CPUContext *device_context){
    Device cpu(DeviceType::kCPU);
    DeviceContextRegister::singleton().set_device_context(cpu, device_context);
  }
};

#define REGISTER_CPUCONTEXT(c)                      \
   static CPUContextRegisterProxy g_cpu_context(c); \

CPUContext* cpu_context();

#endif
