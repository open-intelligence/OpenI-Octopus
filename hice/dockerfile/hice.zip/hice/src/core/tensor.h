#ifndef HICE_TENSOR_H
#define HICE_TENSOR_H

#include <cstddef>
#include "context.h"
#include "expression.h"
#include "evaluator.h"
#include "tensor_storage.h"

template<typename TScalarType, int ndim, typename TIndexType = int, 
         StorageType stype = StorageType::kDense>
class Tensor: public Expr<Tensor<TScalarType, ndim, TIndexType, stype>> {
 public:
  typedef TScalarType Scalar;
  typedef TIndexType Index;
  typedef TensorShape<Index, ndim> Shape;
  typedef TensorStorage<Scalar, ndim, Index, stype> Storage;
  typedef Tensor<Scalar, ndim, Index, stype> Self; 
  typedef Self ResultType;

  Tensor() : storage_() {
    //std::cout << "tensor ctor begin" << std::endl;
    //std::cout << "tensor ctor end" << std::endl;
  }

  explicit Tensor(Index first_dim)
      : storage_(first_dim) {}
  
  template<typename... TIndexTypes>
  Tensor(Index first_dim, Index second_dim, TIndexTypes... other_dims)
      : storage_(first_dim, second_dim, other_dims...) {}

  Tensor(const array<Index, ndim> &shape)
      : storage_(shape) {
    //std::cout << "tensor shape ctor begin" << std::endl;
    //std::cout << "tensor shape ctor end" << std::endl;
  }

  Tensor(Self& other) : storage_(other.storage_) {
    //std::cout << "tensor copy ctor begin" << std::endl;
    //std::cout << "tensor copy ctor end" << std::endl;
  }

  template<typename TExpr>
  Tensor(const Expr<TExpr> &other) {
    //std::cout << "copy expr begin" << std::endl;
    typedef BinaryExpr<Self, TExpr, op::assign> AssignExpr;
    AssignExpr assign_expr(this->self(), other.self());
    Evaluator<AssignExpr> evaluator(assign_expr);
    evaluator.run();
    //std::cout << "copy expr end" << std::endl;
  }

  Self& operator=(Self other) {
    //std::cout << "= tensor begin" << std::endl;
    swap(other);
    //std::cout << "= tensor end" << std::endl;
    return *this;
  }

  void swap(Self &other) {
    storage_.swap(other.storage_);
  }

  template<typename TExpr>
  Self& operator=(const Expr<TExpr> &other) {
    //std::cout << "= expr begin" << std::endl;
    typedef BinaryExpr<Self, TExpr, op::assign> AssignExpr;
    AssignExpr assign_expr(this->self(), other.self());
    Evaluator<AssignExpr> evaluator(assign_expr);
    evaluator.run();
    //std::cout << "= expr end" << std::endl;
    return *this;
  }

  int rank() const { return ndim; }

  int dim(int i) const { return shape().dim(i); }

  size_t size() const { return storage_.size(); }

  const Shape& shape() const { return storage_.shape(); }

  Shape& shape()  { return storage_.shape(); }

  HICE_DEVICE_FUNC const Scalar* data() const { return storage_.data(); }
  HICE_DEVICE_FUNC Scalar* data() { return storage_.data(); }

  HICE_DEVICE_FUNC Scalar* device_data() { return storage_.device_data(); }
  HICE_DEVICE_FUNC const Scalar* device_data() const { return storage_.device_data(); }

  const Device& device() const { return storage_.device(); }

  void to_device(Device device) { storage_.to_device(device); }

  void to_host() { storage_.to_host(); }

  void off_device(Device device) { storage_.off_device(device); }

  template<typename... TIndexTypes>
  const Scalar& at(Index first_idx, Index second_idx, TIndexTypes... other_idxs) const {
    return at(array<Index, ndim>{{first_idx, second_idx, other_idxs...}});
  }

  const Scalar& at(const array<Index, ndim>& indices) const { return storage_.at(indices); }

  const Scalar& at() const { return storage_.at(0); }

  HICE_DEVICE_FUNC
  const Scalar& at(Index idx) const { return storage_.at(idx); }

  template<typename... TIndexTypes>
  Scalar& at(Index first_idx, Index second_idx, TIndexTypes... other_idxs) {
    return at(array<Index, ndim>{{first_idx, second_idx, other_idxs...}});
  }

  Scalar& at(const array<Index, ndim>& indices) {
    return storage_.at(indices);
  }

  Scalar& at() { return storage_.at(0); }

  HICE_DEVICE_FUNC
  Scalar& at(Index idx) { return storage_.at(idx); }

  template<typename... TIndexTypes>
  const Scalar& operator()(Index first_idx, Index second_idx, TIndexTypes... other_idxs) const {
    return this->operator()(array<Index, ndim>{{first_idx, second_idx, other_idxs...}});
  }

  const Scalar& operator()(const array<Index, ndim>& indices) const {
    return at(indices);
  }

  const Scalar& operator()() const { return at(0); }

  const Scalar& operator()(Index idx) const { return at(idx); }

  template<typename... TIndexTypes>
  Scalar& operator()(Index first_idx, Index second_idx, TIndexTypes... other_idxs) {
    return this->operator()(array<Index, ndim>{{first_idx, second_idx, other_idxs...}});
  }

  Scalar& operator()(const array<Index, ndim>& indices) { return at(indices); }

  Scalar& operator()() { return at(0); }

  Scalar& operator()(Index idx) { return at(idx); }

  template<typename... TIndexTypes>
  void resize(Index first_dim, TIndexTypes... other_dims) {
    resize(array<Index, ndim>{{first_dim, other_dims...}});
  }

  void resize(const array<Index, ndim>& dims) { storage_.resize(dims); }

  void resize(const TensorShape<Index, ndim>& shape) {
    array<Index, ndim> dims;
    for (int i = 0; i < ndim; ++i) {
      dims[i] = shape[i];
    }
    resize(dims);
  }

 private:
  Storage storage_;
};

#endif
