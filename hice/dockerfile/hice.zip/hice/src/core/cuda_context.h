#ifndef HICE_CUDA_CONTEXT_H
#define HICE_CUDA_CONTEXT_H

#include <vector>
#include <string>
#include <cuda.h>
#include <cuda_runtime.h>
#include <cublas_v2.h>
#include "device_context.h"
#include "cuda_allocator.h"
#include "cuda_common.h"

#ifdef HICE_USE_CUDNN

#endif // HICE_USE_CUDNN

// Thread-local cuda objects used by cuda context
class CUDAObjects {
 public:
  friend class CUDAContext;
 private:
  CUDAObjects() {
    num_devices_ = cuda_get_num_devices();
    current_stream_idxs_ = new int[num_devices_];
    cuda_props_ = new cudaDeviceProp[num_devices_];
    cuda_streams_ = new std::vector<cudaStream_t>[num_devices_];
    cublas_handles_ = new std::vector<cublasHandle_t>[num_devices_];
#ifdef HICE_USE_CUDNN
    cudnn_handles_ = new std::vector<cudnnHandle_t>[num_devices_];
#endif // HICE_USE_CUDNN
    for (int i = 0; i < num_devices_; ++i) {
      cudaError_t err = cudaGetDeviceProperties(&cuda_props_[i], i);
      if (err != cudaSuccess) {
        std::cerr << "Failed to initialize GPU device #"
                  << i
                  << ": "
                  << cudaGetErrorString(err)
                  << std::endl;
        assert(err == cudaSuccess);
      }
      current_stream_idxs_[i] = 0;
      cuda_streams_[i] = std::vector<cudaStream_t>();
      cublas_handles_[i] = std::vector<cublasHandle_t>();
#ifdef HICE_USE_CUDNN
      cudnn_handles_[i] = std::vector<cudnnHandle_t>();
#endif // HICE_USE_CUDNN
    }
  }

  ~CUDAObjects() {
    for (int i = 0; i < num_devices_; ++i) {
      for (auto &handle : cublas_handles_[i]) {
        if (handle) {
          cublasDestroy(handle);
        }
      }
#ifdef HICE_USE_CUDNN
    for (int i = 0; i < num_devices_; ++i) {
      for (auto &handle : cudnn_handles_[i]) {
        if (handle) {
          cudnnDestroy(handle);
        }
      }
#endif // HICE_USE_CUDNN
      for (auto &stream : cuda_streams_[i]) {
        if (stream) {
          cudaStreamSynchronize(stream);
          cudaError_t error = cudaGetLastError();
          if (error != cudaSuccess) {
            std::cout << "Here 1" << std::endl;
            throw std::runtime_error("Encountered CUDA error: " + 
                std::string(cudaGetErrorString(error)));
          }
          cudaStreamDestroy(stream);
        }
      }
    }
    delete [] current_stream_idxs_;
    delete [] cuda_props_;
    delete [] cuda_streams_;
    delete [] cublas_handles_;
#ifdef HICE_USE_CUDNN
    delete [] cudnn_handles_;
#endif // HICE_USE_CUDNN
  }

  void set_current_stream(int gpu_idx, int stream_idx) {
    current_stream_idxs_[gpu_idx] = stream_idx;
  }

  cudaDeviceProp& cuda_property(int gpu_idx) const {
    return cuda_props_[gpu_idx];
  }

  cudaStream_t stream(int gpu_idx) {
    return stream(gpu_idx, current_stream_idxs_[gpu_idx]);
  }

  cudaStream_t stream(int gpu_idx, int stream_idx);

  cublasHandle_t cublas_handle(int gpu_idx) {
    return cublas_handle(gpu_idx, current_stream_idxs_[gpu_idx]);
  }

  cublasHandle_t cublas_handle(int gpu_idx, int stream_idx);

#ifdef HICE_USE_CUDNN
  cudnnHandle_t cudnn_handle(int gpu_idx) {
    return cudnn_handle(gpu_idx, current_stream_idxs_[gpu_idx]);
  }

  cudnnHandle_t cudnn_handle(int gpu_idx, int stream_idx);

#endif // HICE_USE_CUDNN

 private:
  int num_devices_;
  int *current_stream_idxs_;
  cudaDeviceProp *cuda_props_;
  std::vector<cudaStream_t> * cuda_streams_;
  std::vector<cublasHandle_t> *cublas_handles_;
#ifdef HICE_USE_CUDNN
  std::vector<cudnnHandle_t> *cudnn_handles_;
#endif // HICE_USE_CUDNN
};

class CUDAContext: public DeviceContext {
 public:
  explicit CUDAContext(const int gpu_idx = -1);

  ~CUDAContext() {}

  int device_index() const { return gpu_idx_; }

  DeviceType device_type() const override {
    return DeviceType::kCUDA;
  }

  cudaDeviceProp& cuda_property() const {
    return cuda_objects().cuda_property(gpu_idx_);
  }

  void swith_to_device() {
    cudaSetDevice(gpu_idx_);
  }

  void swith_to_device(int stream_id) {
    CUDAObjects().set_current_stream(gpu_idx_, stream_id);
    cudaSetDevice(gpu_idx_);
  }

  cudaStream_t stream() const {
    return cuda_objects().stream(gpu_idx_);
  }

  cudaStream_t stream(int stream_idx) const {
    return cuda_objects().stream(gpu_idx_, stream_idx);
  }

  static cudaStream_t stream(int gpu_idx, int stream_idx) {
    return cuda_objects().stream(gpu_idx, stream_idx);
  }

  cublasHandle_t cublas_handle() {
    return cuda_objects().cublas_handle(gpu_idx_);
  }

#ifdef HICE_USE_CUDNN
  cudnnHandle_t cudnn_handle() {
    return cuda_objects().cudnn_handle(gpu_idx_);
  }
#endif // HICE_USE_CUDNN

  void synchronize() override {
    cudaStreamSynchronize(cuda_objects().stream(gpu_idx_));
    cudaError_t error = cudaGetLastError();
    if (error != cudaSuccess) {
      throw std::runtime_error("Encountered CUDA error: " + 
          std::string(cudaGetErrorString(error)));
    }
  }

  void* allocate_bytes(std::size_t num_bytes, std::size_t alignment) override {
    return cuda_allocator()->allocate_bytes(num_bytes, alignment);
  }

  void deallocate_bytes(void* ptr) override {
    cuda_allocator()->deallocate_bytes(ptr);
  }

  template <typename T>
  T* allocate_objects(std::size_t num_elems) {
    return cuda_allocator()->allocate_objects<T>(num_elems);
    // return;

  }
  
  template <typename T>
  void deallocate_objects(T* typed_ptr, std::size_t num_elems) {
    cuda_allocator()->deallocate_objects<T>(typed_ptr, num_elems);
  }

  void copy_bytes(const void* src, size_t nbytes,
                  void* dst, CopyDirection direction) override {
    cudaStream_t stream = cuda_objects().stream(gpu_idx_);
    cudaError_t error = cudaMemcpyAsync(dst, src, nbytes, 
        cudaMemcpyDefault, stream);
    if (error != cudaSuccess) {
      std::abort();
      throw std::runtime_error("Encountered CUDA error: " + 
          std::string(cudaGetErrorString(error)));
    }
  }

 private:
  static CUDAObjects& cuda_objects();

  static void initialize();

  struct CUDAInitializer {
    CUDAInitializer() {
      //static std::atomic<char> first_call(1);
      //if (first_call.fetch_and((char)0)) {
      CUDAContext::initialize();
      //}
    }
  };

  int gpu_idx_;
};

class CUDAContextRegisterProxy {
 public:
  CUDAContextRegisterProxy(){
    int num_gpus = cuda_get_num_devices();
    for (int gpu_idx = 0; gpu_idx < num_gpus; ++gpu_idx) {
      Device gpu(DeviceType::kCUDA, gpu_idx);
      DeviceContext *cuda_ctx = new CUDAContext(gpu_idx);
      DeviceContextRegister::singleton().set_device_context(gpu, cuda_ctx);
      dev_ctxs_.push_back(cuda_ctx);
    }
  }

   ~CUDAContextRegisterProxy() {
     for (auto &entry : dev_ctxs_) {
       delete entry;
     }
   }

 private:
   std::vector<DeviceContext *> dev_ctxs_;
};

CUDAContext* cuda_context(Device dev);

#endif
