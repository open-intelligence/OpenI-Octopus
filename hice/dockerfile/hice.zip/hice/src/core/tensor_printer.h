#ifndef HICE_TENSOR_PRINTER_H
#define HICE_TENSOR_PRINTER_H

#include <iostream>
#include "tensor.h"
#include "evaluator.h"

template <typename TTensor, int ndim>
struct TensorPrinter {
  static void print(std::ostream& os, const TTensor& tensor) {
    typedef typename TTensor::Scalar Scalar;
    typedef typename TTensor::Index Index;
    const size_t total_size = tensor.size();
    const Scalar *data = tensor.data();
    if (total_size > 0) {
      const Index nrows = tensor.dim(0);
      const size_t ncols = total_size / nrows;
      for (int i = 0; i < nrows; ++i) {
        for (int j = 0; j < ncols; ++j) {
          os << data[i * ncols + j] << ' ';
        }
        os << std::endl;
      }
    }
  }
};

template <typename TTensor>
struct TensorPrinter<TTensor, 1> {
  static void print(std::ostream& os, const TTensor& tensor) {
    typedef typename TTensor::Scalar Scalar;
    typedef typename TTensor::Index Index;
    const size_t total_size = tensor.size();
    const Scalar *data = tensor.data();
    if (total_size > 0) {
      for (int i = 0; i < total_size; i++)
        os << data[i] << ' ';
      os << std::endl;
    }
  }
};

template <typename TTensor>
struct TensorPrinter<TTensor, 0> {
  static void print(std::ostream& os, const TTensor& tensor) {
    os << tensor(0) << std::endl;
  }
};

template<typename TScalarType, int ndim, 
         typename TIndexType, StorageType stype>
std::ostream& operator<<(std::ostream& os, const Tensor<TScalarType, ndim, TIndexType, stype>& tensor) {
  //std::cout << "<< tensor begin" << std::endl;
  typedef Tensor<TScalarType, ndim, TIndexType, stype> TensorType;
  TensorPrinter<TensorType, ndim>::print(os, tensor);
  //std::cout << "<< tensor end" << std::endl;
  return os;
}


template <typename T>
std::ostream& operator<<(std::ostream& os, const Expr<T>& expr) {
  //std::cout << "<< expr begin" << std::endl;
  typedef UnaryExpr<T, op::eval> EvalExpr;
  typedef Evaluator<EvalExpr> Evaluator;
  typedef typename Evaluator::ResultType ResultType;
  Evaluator evaluator(expr.eval());

  static const int ndim = shape_size<typename ResultType::Shape>::value;
  TensorPrinter<ResultType, ndim>::print(os, evaluator.run());

  //std::cout << "<< expr end" << std::endl;
  return os;
}

#endif
