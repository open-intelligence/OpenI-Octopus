#ifndef HICE_ALLOCATOR_H
#define HICE_ALLOCATOR_H

#include <map>
#include <mutex>
#include <cstddef>
#include "device.h"

class Allocator {
 public:
  static constexpr std::size_t kAlignment = 64;
  virtual ~Allocator() {}
  virtual void* allocate_bytes(std::size_t num_bytes, std::size_t alignment) = 0;
  virtual void deallocate_bytes(void* ptr) = 0;

  //template <typename T>
  //T* allocate_objects(std::size_t num_elems) {
  //  if (num_elems > (std::numeric_limits<std::size_t>::max() / sizeof(T))) {
  //    return nullptr;
  //  }
  //  void* ptr = allocate_bytes(sizeof(T) * num_elems, kAlignment);
  //  return reinterpret_cast<T*>(ptr);
  //}
  //
  //template <typename T>
  //void deallocate_objects(void* ptr, std::size_t num_elems) {
  //  deallocate_bytes(reinterpret_cast<void *>(ptr));
  //}
};

class AllocatorRegister {
 public:
   static AllocatorRegister& singleton() {
     static AllocatorRegister alloc_reg;
     return alloc_reg;
   }

   void set_allocator(DeviceType device_type, Allocator *allocator) {
     std::lock_guard<std::mutex> guard(mu_);
     allocators_[static_cast<int>(device_type)] = allocator;
   } 

   Allocator* get_allocator(DeviceType device_type) {
     return allocators_[static_cast<int>(device_type)];
   }

 private:
   AllocatorRegister() {}  
   AllocatorRegister(AllocatorRegister const&) = delete;
   AllocatorRegister& operator=(AllocatorRegister const&) = delete;
   std::mutex mu_;
   std::map<int, Allocator*> allocators_;
};

class AllocatorRegisterProxy {
 public:
  AllocatorRegisterProxy(DeviceType device_type, Allocator *allocator){
    AllocatorRegister::singleton().set_allocator(device_type, allocator);
  }
};

#define REGISTER_ALLOCATOR(d, a)                    \
   static AllocatorRegisterProxy g_allocator(d, a); \

#endif
