#ifndef HICE_TENSOR_SHAPE_H
#define HICE_TENSOR_SHAPE_H

#include <array>

template <typename T, std::size_t N> using array = std::array<T, N>;

namespace {

template<typename TIndexType, std::size_t ndim, std::size_t n>
struct Linearization {
  static TIndexType linearize(array<TIndexType, ndim> const& indices, 
                              array<TIndexType, ndim> const& shape) {
    return std::get<n>(indices) + std::get<n>(shape) *
        Linearization<TIndexType, ndim, n - 1>::linearize(indices, shape);
  }
};

template<typename TIndexType, std::size_t ndim>
struct Linearization<TIndexType, ndim, 0> {
  static TIndexType linearize(array<TIndexType, ndim> const& indices, 
                         array<TIndexType, ndim> const& shape) {
    return std::get<0>(indices);
  }
};

}

template <typename TIndexType, int ndim>
struct TensorShape : public array<TIndexType, ndim> {
  typedef TIndexType Index;
  typedef TensorShape<TIndexType, ndim> Self;
  typedef array<Index, ndim> Base;

  TensorShape() {
    for (int i = 0 ; i < ndim; ++i) {
      (*this)[i] = 0;
    }
  }

  explicit TensorShape(const Index dim) {
    // static_assert(ndim == 1, "Unatched dimension");
    (*this)[0] = dim;
  }

  template<typename... TIndexTypes>
  TensorShape(
      Index first_dim, 
      Index second_dim, 
      TIndexTypes... other_dims)
      : Base({{first_dim, second_dim, other_dims...}}) {} 

  explicit TensorShape(const array<Index, ndim> &other) : Base(other) { }

  TensorShape& operator=(const array<Index, ndim>& other) {
    *static_cast<Base*>(this) = other;
    return *this;
  }

  void reshape(const Index* dims_) const{
    Index* data_ = const_cast<Index*>(this->data());
    for(int i=0; i<ndim; i++)
      data_[i] = dims_[i];
  }

  int rank() const { return ndim; }

  int dim(int i) const { return (*this)[i]; }

  std::size_t size() const {
    size_t size = 1;
    for (int i = 0; i < ndim; ++i) {
      size *= (*this)[i];
    }
    return size;
  }

 size_t linearize(const array<Index, ndim> &indices) const{
    int linearized = Linearization<Index, ndim, ndim - 1>::linearize(indices, 
        *static_cast<const Base*>(this));
    //std::cout << "linearized " << linearized << std::endl; 
    return Linearization<Index, ndim, ndim - 1>::linearize(indices, 
        *static_cast<const Base*>(this));
 }

};


#endif
