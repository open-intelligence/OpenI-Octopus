#ifndef HICE_OPERATOR_H
#define HICE_OPERATOR_H

#include "tensor.h"
#include "engine.h"

namespace op {

// unary
struct abs{
  template<typename TScalarType>
  HICE_DEVICE_FUNC
  inline static TScalarType apply(const TScalarType val) {
    return std::abs(val);
  }
};

struct negative{
  template<typename TScalarType>
  HICE_DEVICE_FUNC
  inline static TScalarType apply(const TScalarType val) {
    return -1*val;
  }
};

// reduction
struct maximum{
  template<typename TScalarType, int ndim, typename TIndexType, StorageType stype>
  // HICE_DEVICE_FUNC
  inline static void apply(Tensor<TScalarType, ndim, TIndexType, stype> &input, 
                          Tensor<TScalarType, 0, TIndexType, stype> &result, 
                          int dim) {
    //assert(dim==-1, "Wrong tensor type!");
    size_t num_eles = input.size();
    TScalarType* in_data = input.data();
    TScalarType* res_data = result.data();
    res_data[0] = in_data[0];
    for (TIndexType i=0; i<num_eles; ++i){
      if (res_data[0] < in_data[i])
        res_data[0] = in_data[i];
    }
  }

  template<typename TScalarType, int ndim, typename TIndexType, StorageType stype>
  // HICE_DEVICE_FUNC
  inline static void apply(Tensor<TScalarType, ndim, TIndexType, stype> &input, 
                          Tensor<TScalarType, 1, TIndexType, stype> &result, 
                          int dim) {
    // res = result.data();
    // size_t num_eles = input.size();
    // TScalarType* r_data = input.data();
    // res[0] = r_data[0];
    // for (TIndexType i=0; i<num_eles; ++i){
    //   if (res[0] < r_data[i])
    //     res[0] = r_data[i];
    // }
  }
};

struct minimum{

  template<typename TScalarType, int ndim, typename TIndexType, StorageType stype>
  // HICE_DEVICE_FUNC
  inline static void apply(Tensor<TScalarType, ndim, TIndexType, stype> &input, 
                          Tensor<TScalarType, 0, TIndexType, stype> &result, 
                          int dim) {
    size_t num_eles = input.size();
    TScalarType* in_data = input.data();
    TScalarType* res_data = result.data();
    res_data[0] = in_data[0];
    for (TIndexType i=0; i<num_eles; ++i){
      if (res_data[0] > in_data[i])
        res_data[0] = in_data[i];
    }
  }

};

struct sum{

  template<typename TScalarType, int ndim, typename TIndexType, StorageType stype>
  // HICE_DEVICE_FUNC
  inline static void apply(Tensor<TScalarType, ndim, TIndexType, stype> &input, 
                          Tensor<TScalarType, 0, TIndexType, stype> &result, 
                          int dim) {
    size_t num_eles = input.size();
    TScalarType* in_data = input.data();
    TScalarType* res_data = result.data();
    res_data[0] = in_data[0];
    for (TIndexType i=1; i<num_eles; ++i){
        res_data[0] += in_data[i];
    }
  }

};

struct mean{

  template<typename TScalarType, int ndim, typename TIndexType, StorageType stype>
  // HICE_DEVICE_FUNC
  inline static void apply(Tensor<TScalarType, ndim, TIndexType, stype> &input, 
                          Tensor<TScalarType, 0, TIndexType, stype> &result, 
                          int dim) {
    size_t num_eles = input.size();
    TScalarType* in_data = input.data();
    TScalarType* res_data = result.data();
    res_data[0] = in_data[0];
    for (TIndexType i=1; i<num_eles; ++i){
        res_data[0] += in_data[i];
    }
    res_data[0]/=num_eles;
  }

};

struct norm1{

  template<typename TScalarType, int ndim, typename TIndexType, StorageType stype>
  // HICE_DEVICE_FUNC
  inline static void apply(Tensor<TScalarType, ndim, TIndexType, stype> &input, 
                          Tensor<TScalarType, 0, TIndexType, stype> &result, 
                          int dim) {
    size_t num_eles = input.size();
    TScalarType* in_data = input.data();
    TScalarType* res_data = result.data();
    res_data[0] = std::abs(in_data[0]);
    for (TIndexType i=1; i<num_eles; ++i){
        res_data[0] += std::abs(in_data[i]);
    }
  }

};

struct norm2{

  template<typename TScalarType, int ndim, typename TIndexType, StorageType stype>
  // HICE_DEVICE_FUNC
  inline static void apply(Tensor<TScalarType, ndim, TIndexType, stype> &input, 
                          Tensor<TScalarType, 0, TIndexType, stype> &result, 
                          int dim) {
    size_t num_eles = input.size();
    TScalarType* in_data = input.data();
    TScalarType* res_data = result.data();
    res_data[0] = std::pow(in_data[0], 2);
    for (TIndexType i=1; i<num_eles; ++i){
        res_data[0] += std::pow(in_data[i], 2);
    }
    res_data[0] = std::sqrt(res_data[0]);
  }

};

// binary
struct eval {

  template<typename TScalarType1, int ndim, typename TIndexType1, 
           typename TScalarType2, typename TIndexType2,
           StorageType stype>
  // HICE_DEVICE_FUNC
  inline static void apply(Tensor<TScalarType1, ndim, TIndexType1, stype> &input, 
                    Tensor<TScalarType2, ndim, TIndexType2, stype> &result) {
    result.resize(input.shape());
    result = input; 
  }

};

struct assign {

  template<typename TScalarType1, int ndim, typename TIndexType1, 
           typename TScalarType2, typename TIndexType2,
           StorageType stype>
  // HICE_DEVICE_FUNC
  inline static void apply(Tensor<TScalarType1, ndim, TIndexType1, stype> &input, 
                    Tensor<TScalarType2, ndim, TIndexType2, stype> &result) {
    // std::cout << "assign expression begin" << std::endl;
    // std::cout << "result" << std::endl;
    // std::cout << result << std::endl;
    // std::cout << "input" << std::endl;
    // std::cout << input << std::endl;
    result.resize(input.shape());
    result = input;
    // std::cout << result << std::endl;
    // std::cout << "assign expression end" << std::endl;
  }

};

// add driven by blas.
struct add {

  template<typename TScalarType1, int ndim, typename TIndexType1, 
           typename TScalarType2, typename TIndexType2,
           typename TScalarType3, typename TIndexType3,
           StorageType stype>
  // HICE_DEVICE_FUNC
  inline static void apply(Tensor<TScalarType1, ndim, TIndexType1, stype> &lhs, 
                    Tensor<TScalarType2, ndim, TIndexType2, stype> &rhs, 
                    Tensor<TScalarType3, ndim, TIndexType3, stype> &result) {
    result.resize(lhs.shape());
    if (lhs.device() == rhs.device()) {
      if (lhs.device().is_cpu()) {
        engine::copy<DeviceType::kCPU, TScalarType3>(rhs, result);
        engine::axpy<DeviceType::kCPU, TScalarType3>(lhs, result);
      } else if (lhs.device().is_cuda()) {

      }
    } else {
    }
  }

};

// Nullary e-wise
template<typename TScalarType, typename BinaryOp>
struct nullaryop_sleft: public BinaryOp {
  explicit nullaryop_sleft(const TScalarType &scalar):scalar_(scalar){}

  HICE_DEVICE_FUNC
  inline TScalarType apply(TScalarType lhs) const {
    return BinaryOp::apply(lhs, scalar_);
  }

  const TScalarType scalar_;
};

template<typename TScalarType, typename BinaryOp>
struct nullaryop_sright: public BinaryOp {
  explicit nullaryop_sright(const TScalarType &scalar):scalar_(scalar){}

  HICE_DEVICE_FUNC
  inline TScalarType apply(TScalarType rhs) const {
    return BinaryOp::apply(scalar_, rhs);
  }

  const TScalarType scalar_;
};

// binary e-wise
struct multiply {
  template<typename TScalarType1, typename TScalarType2>
  HICE_DEVICE_FUNC
  inline static TScalarType1 apply(TScalarType1 lhs, TScalarType2 rhs) {
    return lhs * rhs;
  }
};

struct divide {
  template<typename TScalarType1, typename TScalarType2>
  HICE_DEVICE_FUNC
  inline static TScalarType1 apply(TScalarType1 lhs, TScalarType2 rhs) {
    return lhs / rhs;
  }
};

struct e_add {
  template<typename TScalarType1, typename TScalarType2>
  HICE_DEVICE_FUNC
  inline static TScalarType1 apply(TScalarType1 lhs, TScalarType2 rhs) {
    return lhs + rhs;
  }
};

struct subtract {
  template<typename TScalarType1, typename TScalarType2>
  HICE_DEVICE_FUNC
  inline static TScalarType1 apply(const TScalarType1 lhs, const TScalarType2 rhs) {
    return lhs - rhs;
  }
};

struct mod {
  template<typename TScalarType1, typename TScalarType2>
  HICE_DEVICE_FUNC
  inline static TScalarType1 apply(const TScalarType1 lhs, const TScalarType2 rhs) {
    return lhs % rhs;
  }
};

// dot
/*
struct dot{

  template<typename TScalarType1, typename TIndexType1, 
           typename TScalarType2, typename TIndexType2,
           typename TScalarType3, typename TIndexType3,
           StorageType stype>
  inline static void apply(Tensor<TScalarType1, 1, TIndexType1, stype> &lhs,
                    Tensor<TScalarType2, 1, TIndexType2, stype> &rhs,
                    Tensor<TScalarType3, 0, TIndexType3, stype> &result) {
    if (lhs.device() == rhs.device()) {
      if (lhs.device().is_cpu()) {
        engine::dotvv<DeviceType::kCPU, TScalarType3>(lhs, rhs, result);
      } else if (lhs.device().is_cuda()) {
        //engine::dotvv<DeviceType::kCUDA, TScalarType3>(lhs, rhs, result);
      }
    } else {
    }
  }

  template<typename TScalarType1, typename TIndexType1, 
           typename TScalarType2, typename TIndexType2,
           typename TScalarType3, typename TIndexType3,
           StorageType stype>
  inline static void apply(Tensor<TScalarType1, 2, TIndexType1, stype> &lhs,
                    Tensor<TScalarType2, 1, TIndexType2, stype> &rhs,
                    Tensor<TScalarType3, 1, TIndexType3, stype> &result) {
    //std::cout << "dot expression begin" << std::endl;
    // result.resize(lhs.dim(0));
    if (lhs.device() == rhs.device()) {
      if (lhs.device().is_cpu()) {
        engine::gemv<DeviceType::kCPU, TScalarType3>(lhs, rhs, result);
      } else if (lhs.device().is_cuda()) {
        engine::gemv<DeviceType::kCUDA, TScalarType3>(lhs, rhs, result);
      }
    } else {
    }
    //std::cout << "dot expression end" << std::endl;
  }

  template<typename TScalarType1, typename TIndexType1, 
           typename TScalarType2, typename TIndexType2,
           typename TScalarType3, typename TIndexType3,
           StorageType stype>
  inline static void apply(Tensor<TScalarType1, 2, TIndexType1, stype> &lhs,
                    Tensor<TScalarType2, 2, TIndexType2, stype> &rhs,
                    Tensor<TScalarType3, 2, TIndexType3, stype> &result) {
    if (lhs.device() == rhs.device()) {
      if (lhs.device().is_cpu()) {
        engine::gemm<DeviceType::kCPU, TScalarType3>(lhs, rhs, result);
      } else if (lhs.device().is_cuda()) {
        // engine<DeviceType::kCUDA, TScalarType3>(lhs, rhs, result);
      }
    } else {
    }
  }
};
*/

}; // namespace op

#endif
