#ifndef HICE_DOT_H
#define HICE_DOT_H

#include "../core/tensor.h"

// Step 1: Write the dot engine with the underlying kernels
namespace engine {

// CPU kernels
template< DeviceType Td, typename TScalarType,  typename TVec, typename TZeroDimTensor>
typename std::enable_if<is_same_device<Td, DeviceType::kCPU>::value, void>::type
dotvv(const TVec &vec1, const TVec &vec2, TZeroDimTensor &result) {
  const int n = vec1.dim(0);
  const int m = vec2.dim(0);
  const int incx = 1;
  const int incy = 1;
  if (std::is_same<TScalarType, float>::value) {
    typedef float T;
    const T *x = (const T*)vec1.data();
    const T *y = (const T*)vec2.data();
    (T &)result.at(0) = cblas_sdot(n, x, incx, y, incy);
  }else if (std::is_same<TScalarType, double>::value) {
    typedef double T;
    const T *x = (const T*)vec1.data();
    const T *y = (const T*)vec2.data();
    (T &)result.at(0) = cblas_ddot(n, x, incx, y, incy);
  }else if (std::is_same<TScalarType, std::complex<float>>::value) {
    typedef std::complex<float> T;
    const T *x = (const T*)vec1.data();
    const T *y = (const T*)vec2.data();
    T *res = (T*)result.data();
    cblas_cdotu_sub(n, x, incx, y, incy, res);
  }else if (std::is_same<TScalarType, std::complex<double>>::value) {
    typedef std::complex<double> T;
    const T *x = (const T*)vec1.data();
    const T *y = (const T*)vec2.data();
    T *res = (T*)result.data();
    cblas_zdotu_sub(n, x, incx, y, incy, res);
  }  
}

template< DeviceType Td, typename TScalarType, typename TMat, typename TVec>
typename std::enable_if<is_same_device<Td, DeviceType::kCPU>::value, void>::type
gemv(const TMat &mat, const TVec &vec, TVec &result,
     const TScalarType alpha = TScalarType(1), 
     const TScalarType beta = TScalarType(0),
     bool do_trans = false) {
  CBLAS_TRANSPOSE trans = do_trans ? 
                       (is_complex<TScalarType>::value ? CblasConjTrans : CblasTrans) : 
                       CblasNoTrans;
  const int m = mat.dim(0);
  const int n = mat.dim(1);
  const int incx = 1;
  const int incy = 1;
  if (std::is_same<TScalarType, float>::value) {
    typedef float T;
    const T *a = (const T*)mat.data();
    const T *x = (const T*)vec.data();
    T *y = (T*)result.data();
    cblas_sgemv(CblasRowMajor, trans, m, n, 
       alpha, a, n, x, incx, 
       beta, y, incy);
  } else if (std::is_same<TScalarType, double>::value) {
    typedef double T;
    const T *a = (const T*)mat.data();
    const T *x = (const T*)vec.data();
    T *y = (T*)result.data();
    cblas_dgemv(CblasRowMajor, trans, m, n, 
       alpha, a, n, x, incx, 
       beta, y, incy);
  } else if (std::is_same<TScalarType, std::complex<float>>::value) {
    typedef std::complex<float> T;
    const T *a = (const T*)mat.data();
    const T *x = (const T*)vec.data();
    T *y = (T*)result.data();
    cblas_cgemv(CblasRowMajor, trans, m, n, 
       (const T*)&alpha, a, n, x, incx, 
       (const T*)&beta, y, incy);
  } else if (std::is_same<TScalarType, std::complex<double>>::value) {
    typedef std::complex<double> T;
    const T *a = (const T*)mat.data();
    const T *x = (const T*)vec.data();
    T *y = (T*)result.data();
    cblas_zgemv(CblasRowMajor, trans, m, n, 
       (const T*)&alpha, a, n, x, incx, 
       (const T*)&beta, y, incy);
  }
}

template< DeviceType Td, typename TScalarType, typename TMat>
typename std::enable_if<is_same_device<Td, DeviceType::kCPU>::value, void>::type
gemm(const TMat &mat1, const TMat &mat2, TMat &result,
     const TScalarType alpha = TScalarType(1), 
     const TScalarType beta = TScalarType(0),
     bool do_trans = false) {
  CBLAS_TRANSPOSE transa = do_trans ? 
                       (is_complex<TScalarType>::value ? CblasConjTrans : CblasTrans) : 
                       CblasNoTrans;
  CBLAS_TRANSPOSE transb = do_trans ? 
                       (is_complex<TScalarType>::value ? CblasConjTrans : CblasTrans) : 
                       CblasNoTrans;

  const int m = mat1.dim(0);
  const int k1 = mat1.dim(1);
  const int k2 = mat2.dim(0);
  const int n = mat2.dim(1);
  // check k1==k2, here we suppose k1=k2
  const int k = k1;
  // first dimension
  const int lda = m;
  const int ldb = k;
  const int ldc = m;

  if (std::is_same<TScalarType, float>::value) {
    typedef float T;
    const T *a = (const T*)mat1.data();
    const T *b = (const T*)mat2.data();
    T *c = (T*)result.data();
    cblas_sgemm(CblasRowMajor, transa, transb, m, n, k, 
                alpha, a, lda, b, ldb,
                beta, c, ldc);
  } else if (std::is_same<TScalarType, double>::value) {
    typedef double T;
    const T *a = (const T*)mat1.data();
    const T *b = (const T*)mat2.data();
    T *c = (T*)result.data();
    cblas_dgemm(CblasRowMajor, transa, transb, m, n, k, 
                alpha, a, lda, b, ldb,
                beta, c, ldc);
  } else if (std::is_same<TScalarType, std::complex<float>>::value) {
    typedef std::complex<float> T;
    const T *a = (const T*)mat1.data();
    const T *b = (const T*)mat2.data();
    T *c = (T*)result.data();
    cblas_cgemm(CblasRowMajor, transa, transb, m, n, k, 
                (const T*)&alpha, a, lda, b, ldb,
                (const T*)&beta, c, ldc);
  } else if (std::is_same<TScalarType, std::complex<double>>::value) {
    typedef std::complex<double> T;
    const T *a = (const T*)mat1.data();
    const T *b = (const T*)mat2.data();
    T *c = (T*)result.data();
    cblas_zgemm(CblasRowMajor, transa, transb, m, n, k, 
                (const T*)&alpha, a, lda, b, ldb,
                (const T*)&beta, c, ldc);
  }
}

// GPU kernels
template< DeviceType Td, typename TScalarType,  typename TVec, typename TZeroDimTensor>
typename std::enable_if<is_same_device<Td, DeviceType::kCUDA>::value, void>::type
dotvv(const TVec &vec1, const TVec &vec2, TZeroDimTensor &result) {
  CUDAContext *cuda_ctx = cuda_context(vec1.device());
  cublasHandle_t handle = cuda_ctx->cublas_handle();
  const int n = vec1.dim(0);
  const int m = vec2.dim(0);
  const int incx = 1;
  const int incy = 1;
  if (std::is_same<TScalarType, float>::value) {
    typedef float T;
    const T *x = (const T*)vec1.device_data();
    const T *y = (const T*)vec2.device_data();
    T *res = (T*)result.data();
    cublasStatus_t status = cublasSdot(handle, n, x, incx, y, incy, res);
  }else if (std::is_same<TScalarType, double>::value) {
    typedef double T;
    const T *x = (const T*)vec1.device_data();
    const T *y = (const T*)vec2.device_data();
    T *res = (T*)result.data();
    cublasStatus_t status = cublasDdot(handle, n, x, incx, y, incy, res);
  }else if (std::is_same<TScalarType, std::complex<float>>::value) {
    typedef cuFloatComplex T;
    const T *x = (const T*)vec1.device_data();
    const T *y = (const T*)vec2.device_data();
    T *res = (T*)result.data();
    cublasStatus_t status = cublasCdotu(handle, n, x, incx, y, incy, res);
  }else if (std::is_same<TScalarType, std::complex<double>>::value) {
    typedef cuDoubleComplex T;
    const T *x = (const T*)vec1.device_data();
    const T *y = (const T*)vec2.device_data();
    T *res = (T*)result.data();
    cublasStatus_t status = cublasZdotu(handle, n, x, incx, y, incy, res);
  }  
  //result.to_host();
}

template< DeviceType Td, typename TScalarType, typename TMat, typename TVec>
typename std::enable_if<is_same_device<Td, DeviceType::kCUDA>::value, void>::type
gemv(const TMat &mat, const TVec &vec, TVec &result,
    const TScalarType alpha = TScalarType(1), 
    const TScalarType beta = TScalarType(0),
    bool do_trans = false) {
  result.to_device(mat.device());
  CUDAContext *cuda_ctx = cuda_context(mat.device());
  cublasHandle_t handle = cuda_ctx->cublas_handle();
  cublasOperation_t trans = do_trans ? 
      (is_complex<TScalarType>::value ? CUBLAS_OP_C : CUBLAS_OP_T) : 
      CUBLAS_OP_N;
  const int m = mat.dim(0);
  const int n = mat.dim(1);
  const int lda = n;
  const int incx = 1;
  const int incy = 1;
  if (std::is_same<TScalarType, float>::value) {
    typedef float T;
    const T *a = (const T*)mat.device_data();
    const T *x = (const T*)vec.device_data();
    T *y = (T*)result.device_data();
    cublasStatus_t status = cublasSgemv(handle, trans, m, n,
                         (const T*)&alpha,
                         a, lda,
                         x, incx,
                         (const T*)&beta,
                         y, incy);
  } else if (std::is_same<TScalarType, double>::value) {
    typedef double T;
    const T *a = (const T*)mat.device_data();
    const T *x = (const T*)vec.device_data();
    T *y = (T*)result.device_data();
    cublasStatus_t status = cublasDgemv(handle, trans, m, n,
                         (const T*)&alpha,
                         a, lda,
                         x, incx,
                         (const T*)&beta,
                         y, incy);
  } else if (std::is_same<TScalarType, std::complex<float>>::value) {
    typedef cuFloatComplex T;
    const T *a = (const T*)mat.device_data();
    const T *x = (const T*)vec.device_data();
    T *y = (T*)result.device_data();
    cublasStatus_t status = cublasCgemv(handle, trans, m, n,
                         (const T*)&alpha,
                         a, lda,
                         x, incx,
                         (const T*)&beta,
                         y, incy);
  } else if (std::is_same<TScalarType, std::complex<double>>::value) {
    typedef cuDoubleComplex T;
    const T *a = (const T*)mat.device_data();
    const T *x = (const T*)vec.device_data();
    T *y = (T*)result.device_data();
    cublasStatus_t status = cublasZgemv(handle, trans, m, n,
                         (const T*)&alpha,
                         a, lda,
                         x, incx,
                         (const T*)&beta,
                         y, incy);
  }
  result.to_host();
}

template< DeviceType Td, typename TScalarType, typename TMat>
typename std::enable_if<is_same_device<Td, DeviceType::kCUDA>::value, void>::type
gemm(const TMat &mat1, const TMat &mat2, TMat &result,
     const TScalarType alpha = TScalarType(1), 
     const TScalarType beta = TScalarType(0),
     bool do_trans = false) {
       
  // std::cout<<"gemm begin"<<std::endl;
  result.to_device(mat1.device());
  CUDAContext *cuda_ctx = cuda_context(mat1.device());
  cublasHandle_t handle = cuda_ctx->cublas_handle();
  cublasOperation_t transa = do_trans ? 
      (is_complex<TScalarType>::value ? CUBLAS_OP_C : CUBLAS_OP_T) : 
      CUBLAS_OP_N;
  cublasOperation_t transb = do_trans ? 
      (is_complex<TScalarType>::value ? CUBLAS_OP_C : CUBLAS_OP_T) : 
      CUBLAS_OP_N;

  const int m = mat1.dim(0);
  const int k1 = mat1.dim(1);
  const int k2 = mat2.dim(0);
  const int n = mat2.dim(1);
  // check k1==k2, here we suppose k1=k2
  const int k = k1;
  // first dimension
  const int lda = m;
  const int ldb = k;
  const int ldc = m;

  if (std::is_same<TScalarType, float>::value) {
    typedef float T;
    const T *a = (const T*)mat1.device_data();
    const T *b = (const T*)mat2.device_data();
    T *c = (T*)result.device_data();
    cublasStatus_t status = cublasSgemm(handle, transa, transb, m, n, k,
                           (const T*)&alpha,
                           a, lda,
                           b, ldb,
                           (const T*)&beta,
                           c, ldc);
  } else if (std::is_same<TScalarType, double>::value) {
    typedef double T;
    const T *a = (const T*)mat1.device_data();
    const T *b = (const T*)mat2.device_data();
    T *c = (T*)result.device_data();
    cublasStatus_t status = cublasDgemm(handle, transa, transb, m, n, k,
                           (const T*)&alpha,
                           a, lda,
                           b, ldb,
                           (const T*)&beta,
                           c, ldc);
  } else if (std::is_same<TScalarType, std::complex<float>>::value) {
    typedef cuFloatComplex T;
    const T *a = (const T*)mat1.device_data();
    const T *b = (const T*)mat2.device_data();
    T *c = (T*)result.device_data();
    cublasStatus_t status = cublasCgemm(handle, transa, transb, m, n, k,
                           (const T*)&alpha,
                           a, lda,
                           b, ldb,
                           (const T*)&beta,
                           c, ldc);
  } else if (std::is_same<TScalarType, std::complex<double>>::value) {
    typedef cuDoubleComplex T;
    const T *a = (const T*)mat1.device_data();
    const T *b = (const T*)mat2.device_data();
    T *c = (T*)result.device_data();
    cublasStatus_t status = cublasZgemm(handle, transa, transb, m, n, k,
                           (const T*)&alpha,
                           a, lda,
                           b, ldb,
                           (const T*)&beta,
                           c, ldc);
  }
  result.to_host();
  // std::cout<<"gemm end"<<std::endl;
}

};

// Step 2: Write the dot operator
namespace op {

struct dot {

  template<typename TScalarType1, typename TIndexType1, 
           typename TScalarType2, typename TIndexType2,
           typename TScalarType3, typename TIndexType3,
           StorageType stype>
  inline static void apply(Tensor<TScalarType1, 1, TIndexType1, stype> &lhs,
                    Tensor<TScalarType2, 1, TIndexType2, stype> &rhs,
                    Tensor<TScalarType3, 0, TIndexType3, stype> &result) {
    // std::cout<<"struct dot"<<std::endl;
    if (lhs.device() == rhs.device()) {
      if (lhs.device().is_cpu()) {
        engine::dotvv<DeviceType::kCPU, TScalarType3>(lhs, rhs, result);
      } else if (lhs.device().is_cuda()) {
        engine::dotvv<DeviceType::kCUDA, TScalarType3>(lhs, rhs, result);
      }
    } else {
    }
  }

  template<typename TScalarType1, typename TIndexType1, 
           typename TScalarType2, typename TIndexType2,
           typename TScalarType3, typename TIndexType3,
           StorageType stype>
  inline static void apply(Tensor<TScalarType1, 2, TIndexType1, stype> &lhs,
                    Tensor<TScalarType2, 1, TIndexType2, stype> &rhs,
                    Tensor<TScalarType3, 1, TIndexType3, stype> &result) {
    //std::cout << "dot expression begin" << std::endl;
    // result.resize(lhs.dim(0));
    if (lhs.device() == rhs.device()) {
      if (lhs.device().is_cpu()) {
        engine::gemv<DeviceType::kCPU, TScalarType3>(lhs, rhs, result);
      } else if (lhs.device().is_cuda()) {
        engine::gemv<DeviceType::kCUDA, TScalarType3>(lhs, rhs, result);
      }
    } else {
    }
    //std::cout << "dot expression end" << std::endl;
  }

  template<typename TScalarType1, typename TIndexType1, 
           typename TScalarType2, typename TIndexType2,
           typename TScalarType3, typename TIndexType3,
           StorageType stype>
  inline static void apply(Tensor<TScalarType1, 2, TIndexType1, stype> &lhs,
                    Tensor<TScalarType2, 2, TIndexType2, stype> &rhs,
                    Tensor<TScalarType3, 2, TIndexType3, stype> &result) {
    if (lhs.device() == rhs.device()) {
      if (lhs.device().is_cpu()) {
        engine::gemm<DeviceType::kCPU, TScalarType3>(lhs, rhs, result);
      } else if (lhs.device().is_cuda()) {
        engine::gemm<DeviceType::kCUDA, TScalarType3>(lhs, rhs, result);
      }
    } else {
    }
  }
};

};

// Step 3: Define the DotExpr
template<typename TLhs, typename TRhs>
class DotExpr: public Expr<DotExpr<TLhs, TRhs>> {
 public:
 	explicit DotExpr(const TLhs &lhs, const TRhs &rhs)
       : lhs_(lhs), rhs_(rhs), device_(DeviceType::kCPU) {}
 
  const TLhs& lhs() const { return lhs_; }
 
  const TRhs& rhs() const { return rhs_; }
 
  const Device& device() const { return device_; } 

  void to_device(Device device) { 
    const_cast<TLhs &>(lhs_).to_device(device);
    const_cast<TRhs &>(rhs_).to_device(device);
    device_ = device;
  }

  void off_device(Device device) {
    lhs_.off_device(device);
    rhs_.off_device(device);
    device_ = Device(DeviceType::kCPU); 
  }
 
 private:
 	const TLhs &lhs_;
 	const TRhs &rhs_;
  Device device_;
};

// May need the helper function for DotExpr
template<typename TLhs, typename TRhs>
inline DotExpr<TLhs, TRhs>
dot(const Expr<TLhs> &lhs, const Expr<TRhs> &rhs) {
  return DotExpr<TLhs, TRhs>(lhs.self(), rhs.self());
}

// May need the traits of DotExpr
template<typename TLhs, typename TRhs>
struct Traits<DotExpr<TLhs, TRhs>> {
  static const int kLhsDim = Traits<TLhs>::kDim;
  static const int kRhsDim = Traits<TRhs>::kDim;
  static const bool InvalidDim = kLhsDim < 0 || kRhsDim < 0;
  static const bool Vector_Vector = kLhsDim == 1 && kRhsDim == 1;
  static const bool Matrix_Vector = kLhsDim == 2 && kRhsDim == 1;
  static const bool Matrix_Matrix = kLhsDim == 2 && kRhsDim == 2;
  static const int kDim = InvalidDim ? -1: (
                            Vector_Vector ? 0 : ( 
                              Matrix_Vector ? 1 : (
                                Matrix_Matrix ? 2 : (
                                  kLhsDim == kRhsDim ? kLhsDim : -1
                                )
                              )
                            )
                          );
  static const StorageType kSType = Traits<TLhs>::kSType;
  typedef typename Traits<TLhs>::ScalarType ScalarType;
  typedef typename Traits<TLhs>::IndexType IndexType;
  typedef TensorShape<IndexType, kDim> ShapeType;
  typedef Tensor<ScalarType, kDim, IndexType, kSType> ResultType;
};

// Step 4: Write the evaluator for DotExpr
template<typename TScalarType1, typename TIndexType1, 
         typename TScalarType2, typename TIndexType2,
         StorageType stype>
class Evaluator<DotExpr<Tensor<TScalarType1, 1, TIndexType1, stype>, 
                           Tensor<TScalarType2, 1, TIndexType2, stype>>> {
 public:
  typedef Tensor<TScalarType1, 1, TIndexType1, stype> TLhs;
  typedef Tensor<TScalarType2, 1, TIndexType2, stype> TRhs;
  typedef DotExpr<TLhs, TRhs> ExprType;
  static const int kDim = Traits<ExprType>::kDim;
  typedef typename Traits<ExprType>::IndexType IndexType;
  typedef typename Traits<ExprType>::ShapeType ShapeType;
  typedef typename Traits<ExprType>::ResultType ResultType;
  typedef typename Traits<ExprType>::ScalarType ScalarType;

  explicit Evaluator(const ExprType &expr)
      : lhs_eval_(expr.lhs()), rhs_eval_(expr.rhs()), 
        result_(), shape_(),
        device_(expr.device()) {}

  const ShapeType& shape() const {
    return shape_;
  }

  const Device& device() const {
    return device_;
  }

  void eval_sub_expr_to_support_element_wise(){
    this->run();
  }

  ResultType& run() {
    // std::cout<<"Evaluator.run"<<std::endl;
    op::dot::apply(lhs_eval_.run(), rhs_eval_.run(), result_);
    return result_;
  }

  // calculate
  HICE_DEVICE_FUNC
  ScalarType calc(IndexType i){
    ScalarType* data = NULL;
    if (device_.is_cpu()) {
      data = result_.data();
    }else if (device_.is_cuda()) {
      data = result_.device_data();
    }else {

    }
    return data[i];
  }

 private:
  Evaluator<TLhs> lhs_eval_;
  Evaluator<TRhs> rhs_eval_;
  ResultType result_;
  ShapeType shape_;
  Device device_;
};

template<typename TScalarType1, typename TIndexType1, 
         typename TScalarType2, typename TIndexType2,
         StorageType stype>
class Evaluator<DotExpr<Tensor<TScalarType1, 2, TIndexType1, stype>, 
                           Tensor<TScalarType2, 1, TIndexType2, stype>>> {
 public:
  typedef Tensor<TScalarType1, 2, TIndexType1, stype> TLhs;
  typedef Tensor<TScalarType2, 1, TIndexType2, stype> TRhs;
  typedef DotExpr<TLhs, TRhs> ExprType;
  static const int kDim = Traits<ExprType>::kDim;
  typedef typename Traits<ExprType>::IndexType IndexType;
  typedef typename Traits<ExprType>::ShapeType ShapeType;
  typedef typename Traits<ExprType>::ResultType ResultType;
  typedef typename Traits<ExprType>::ScalarType ScalarType;

  explicit Evaluator(const ExprType &expr) 
      : lhs_eval_(expr.lhs()), rhs_eval_(expr.rhs()), 
        result_(), shape_(lhs_eval_.shape().dim(0)),
        device_(expr.device()) {}

  const ShapeType& shape() const {
    return shape_;
  }

  const Device& device() const {
    return device_;
  }

  void eval_sub_expr_to_support_element_wise(){
    this->run();
  }

  ResultType& run() {
    result_.resize(shape());
    op::dot::apply(lhs_eval_.run(), rhs_eval_.run(), result_);
    return result_;
  }

  // calculate
  HICE_DEVICE_FUNC
  ScalarType calc(IndexType i){
    ScalarType* data = NULL;
    if (device_.is_cpu()) {
      data = result_.data();
    }else if (device_.is_cuda()) {
      data = result_.device_data();
    }else {

    }
    return data[i];
  }

 private:
  Evaluator<TLhs> lhs_eval_;
  Evaluator<TRhs> rhs_eval_;
  ResultType result_;
  ShapeType shape_;
  Device device_;
};

template<typename TScalarType1, typename TIndexType1, 
         typename TScalarType2, typename TIndexType2,
         StorageType stype>
class Evaluator<DotExpr<Tensor<TScalarType1, 2, TIndexType1, stype>, 
                           Tensor<TScalarType2, 2, TIndexType2, stype>>> {
 public:
  typedef Tensor<TScalarType1, 2, TIndexType1, stype> TLhs;
  typedef Tensor<TScalarType2, 2, TIndexType2, stype> TRhs;
  typedef DotExpr<TLhs, TRhs> ExprType;
  static const int kDim = Traits<ExprType>::kDim;
  typedef typename Traits<ExprType>::IndexType IndexType;
  typedef typename Traits<ExprType>::ShapeType ShapeType;
  typedef typename Traits<ExprType>::ResultType ResultType;
  typedef typename Traits<ExprType>::ScalarType ScalarType;

  explicit Evaluator(const ExprType &expr) 
      : lhs_eval_(expr.lhs()), rhs_eval_(expr.rhs()), 
        result_(), shape_(lhs_eval_.shape().dim(0), rhs_eval_.shape().dim(1)),
        device_(expr.device()) {}

  const ShapeType& shape() const {
    return shape_;
  }

  const Device& device() const {
    return device_;
  }

  void eval_sub_expr_to_support_element_wise(){
    this->run();
  }

  ResultType& run() {
    result_.resize(shape());
    op::dot::apply(lhs_eval_.run(), rhs_eval_.run(), result_);
    return result_;
  }

  // calculate
  HICE_DEVICE_FUNC
  ScalarType calc(IndexType i){
    ScalarType* data = NULL;
    if (device_.is_cpu()) {
      data = result_.data();
    }else if (device_.is_cuda()) {
      data = result_.device_data();
    }else {

    }
    return data[i];
  }

 private:
  Evaluator<TLhs> lhs_eval_;
  Evaluator<TRhs> rhs_eval_;
  ResultType result_;
  ShapeType shape_;
  Device device_;
};

#endif
