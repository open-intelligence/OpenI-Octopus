#ifndef HICE_TRANSPOSE_H
#define HICE_TRANSPOSE_H

#include "../core/tensor.h"

namespace op {

struct transpose {
  template<typename TScalarType, int dim, typename TIndexType, StorageType stype>
  inline static void apply(Tensor<TScalarType, dim, TIndexType, stype> &lrhs, 
                           Tensor<TScalarType, dim, TIndexType, stype> &result) {
    if (dim != 2) {
      std::cerr<<"Transpose error because dim != 2."<<std::endl;
      return;
    }
    const int m = lrhs.dim(0);
    const int n = lrhs.dim(1);
    for(int i=0; i<m; i++){
      for(int j=0; j<n; j++){
        result.at(m*j+i) = lrhs.at(n*i+j);
      }
    }
    if (lrhs.device().is_cpu()) {
      
    } else if (lrhs.device().is_cuda()) {
    }
  }
};

};
template<typename TExpr>
class TransposeExpr: public Expr<TransposeExpr<TExpr>> {
 public:
	explicit TransposeExpr(const TExpr &expr)
       : expr_(expr), device_(DeviceType::kCPU) {}

  const TExpr& expr() const { return expr_; }
  
  const Device& device() const { return device_; }

  void to_device(Device device) { 
    const_cast<TExpr &>(expr_).to_device(device);
    device_ = device;
  }

  void off_device(Device device) {
    expr_.off_device(device);
    device_ = Device(DeviceType::kCPU); 
  }

 private:
	const TExpr &expr_;
  Device device_;
};

template<typename TExpr>
inline TransposeExpr<TExpr>
transpose(const Expr<TExpr> &expr) {
  return TransposeExpr<TExpr>(expr.self());
}

template<typename TExpr>
struct Traits<TransposeExpr<TExpr>> {
  static const int kDim = Traits<TExpr>::kDim;
  static const StorageType kSType = Traits<TExpr>::kSType;
  typedef typename Traits<TExpr>::ScalarType ScalarType;
  typedef typename Traits<TExpr>::IndexType IndexType;
  typedef typename Traits<TExpr>::ShapeType ShapeType;
  typedef typename Traits<TExpr>::ResultType ResultType;
};

template<typename TExpr>
class Evaluator<TransposeExpr<TExpr>> {
 public:
  typedef TransposeExpr<TExpr> ExprType;
  typedef typename Traits<ExprType>::ShapeType ShapeType;
  typedef typename Traits<ExprType>::IndexType IndexType;
  typedef typename Traits<ExprType>::ScalarType ScalarType;
  typedef typename Traits<ExprType>::ResultType ResultType;

  explicit Evaluator(const ExprType &expr) : eval_(expr.expr()), result_(), device_(expr.device()) {}

  const ShapeType& shape() const {
    return eval_.shape();
  }

  const Device& device() const {
    return device_;
  }

  // this function will be called if there will be element-wise operation in run(). 
  void eval_sub_expr_to_support_element_wise(){
    this->run();
  }

  ResultType& run() {
    result_.resize(shape());
    op::transpose::apply(eval_.run(), result_);
    return result_;
  }

  // calculate
  HICE_DEVICE_FUNC
  ScalarType calc(IndexType i){
    ScalarType* data = NULL;
    if (device_.is_cpu()) {
      data = result_.data();
    }else if (device_.is_cuda()) {
      data = result_.device_data();
    }else {

    }
    return data[i];
  }

 private:
  Evaluator<TExpr> eval_;
  ResultType result_;
  Device device_;
};

#endif
