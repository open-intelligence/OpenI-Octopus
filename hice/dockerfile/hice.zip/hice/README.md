# hice
High-performance intelligent computation engine（HICE）
