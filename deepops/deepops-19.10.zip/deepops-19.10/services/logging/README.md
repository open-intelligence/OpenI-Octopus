https://github.com/kubernetes/kubernetes/tree/master/cluster/addons/fluentd-elasticsearch
