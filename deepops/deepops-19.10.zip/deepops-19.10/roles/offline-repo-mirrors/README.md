offline-repo-mirrors role
=========================

Builds an offline cache of DeepOps dependencies and produces one big tar file.
Intended to help with setting up DeepOps in environments without Internet connectivity,
such as air-gapped secure environments.
