

# MAAS

## NVIDIA GPU specific tasks

Disable the nouveau driver by setting "Global Kernel Parameters":

```sh
rdblacklist=nouveau
```

